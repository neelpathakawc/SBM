//package com.awcsoftware.spring.data.jpa;
/*
 * package com.awcsoftware.spring.data.jpa;
 * 
 * import javax.sql.DataSource;
 * 
 * import org.springframework.beans.factory.annotation.Autowired; import
 * org.springframework.boot.jdbc.DataSourceBuilder; import
 * org.springframework.context.annotation.Bean; import
 * org.springframework.context.annotation.Configuration;
 * 
 * import com.zaxxer.hikari.HikariConfig; import
 * com.zaxxer.hikari.HikariDataSource;
 * 
 * @Configuration public class JpaConfig { DataSource datasource;
 * 
 * @Autowired private DBProperties dbProperties;
 * 
 * @Bean public DataSource getDataSource() {
 
 * 
 * if (datasource == null) { HikariConfig config = new HikariConfig();
 * config.setJdbcUrl(dbProperties.getUrl());
 * config.setUsername(dbProperties.getUser_name());
 * config.setPassword(dbProperties.getPassword());
 * config.setMaximumPoolSize(10); config.setAutoCommit(false);
 * config.addDataSourceProperty("cachePrepStmts", "true");
 * config.addDataSourceProperty("prepStmtCacheSize", "250");
 * config.addDataSourceProperty("prepStmtCacheSqlLimit", "2048");
 * 
 * datasource = new HikariDataSource(config); } return datasource;
 * 
 * 
 * DataSourceBuilder dataSourceBuilder = DataSourceBuilder.create();
 * dataSourceBuilder.driverClassName(dbProperties.getDriver());
 * dataSourceBuilder.url(dbProperties.getUrl());
 * dataSourceBuilder.username(dbProperties.getUser_name());
 * dataSourceBuilder.password(dbProperties.getPassword()); return
 * dataSourceBuilder.build(); } }
 */