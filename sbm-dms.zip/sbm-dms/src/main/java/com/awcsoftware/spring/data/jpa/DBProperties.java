package com.awcsoftware.spring.data.jpa;

import org.apache.log4j.Logger;
import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "database")
public class DBProperties {
	final static Logger LOGGER = Logger.getLogger(DBProperties.class);
	private String driver;
	private String url;
	private String user_name;
	private String password;

	public String getDriver() {
		return driver;
	}

	public void setDriver(String driver) {
		this.driver = driver;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getUser_name() {
		return user_name;
	}

	public void setUser_name(String user_name) {
		LOGGER.info("setUser_name called");
		this.user_name = user_name;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

}
