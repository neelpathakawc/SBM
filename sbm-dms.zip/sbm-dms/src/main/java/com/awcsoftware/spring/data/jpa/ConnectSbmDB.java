package com.awcsoftware.spring.data.jpa;

import java.sql.Connection;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.apache.commons.dbcp.BasicDataSource;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.awcsoftware.exception.SbmException;

/**
 * @author Shuaib
 *
 */
@Component
public class ConnectSbmDB {

	static final Logger LOGGER = Logger.getLogger(ConnectSbmDB.class);
	private static BasicDataSource bds;
	@Autowired
	private DBProperties dbProperties;

	static {
		if (bds == null) {
			bds = new BasicDataSource();
			bds.setInitialSize(10);
			bds.setMaxActive(10);
		}
	}

	public Connection getConnection() {
		Connection conn=null;
		try {
			LOGGER.info("Entered getConnection()"+"\n bds=" + bds);
			LOGGER.debug("Reading Properties through @ConfigurationProperties");
			bds.setDriverClassName(this.dbProperties.getDriver());
			LOGGER.debug(bds.getDriverClassName());
			bds.setUrl(this.dbProperties.getUrl());
			LOGGER.debug(bds.getUrl());
			bds.setUsername(this.dbProperties.getUser_name());
			LOGGER.debug(bds.getUsername());
			bds.setPassword(this.dbProperties.getPassword());
			LOGGER.debug(bds.getPassword());

			conn = bds.getConnection();
			LOGGER.debug("conn=" + conn + "\t conn.getClientInfo()=" + conn.getClientInfo() + "\tbds.getInitialSize()= "
					+ bds.getInitialSize() + "\tbds.getMaxActive()" + bds.getMaxActive());
			LOGGER.debug("conn=" + conn);
		} catch (Exception e) {
			LOGGER.error("SQLException Caught");
			throw new SbmException("Error in getting connection from the Datasource!");
//			e.printStackTrace();
		}
		return conn;
	}
	/*
	 * final static Logger LOGGER = Logger.getLogger(ConnectSbmDB.class); //
	 * private static BasicDataSource bds; //// @Autowired //// private Environment
	 * env; // @Autowired // private DBProperties dbProperties; // static { // if
	 * (bds == null) // bds = new BasicDataSource(); // } private static DataSource
	 * bds;
	 * 
	 * @Autowired private static JpaConfig jpaConfig; static { if (bds == null) bds
	 * = jpaConfig.getDataSource(); }
	 * 
	 * 
	 * private ConnectSbmDB() {
	 * bds.setDriverClassName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
	 * 
	 * bds.setUrl("jdbc:sqlserver://10.100.30.78:1433;databaseName=oppo");
	 * LOGGER.info("URL got set");
	 * 
	 * bds.setUsername("sa"); LOGGER.info("Username got set");
	 * 
	 * bds.setPassword("P@ssw0rd"); LOGGER.info("Password got set"); }
	 * 
	 * 
	 * public static BasicDataSource getInstance() { if (bds == null) bds = new
	 * BasicDataSource(); return bds; }
	 * 
	 * 
	 * public Connection getConnection() { Connection conn = null;
	 * 
	 * try { LOGGER.info("Entered getConnection()");
	 * LOGGER.info("Reading Properties through @ConfigurationProperties"); //
	 * bds.getConnection(); // bds.setDriverClassName(dbProperties.getDriver()); //
	 * // bds.setUrl(dbProperties.getUrl()); // LOGGER.info("URL got set"); // //
	 * bds.setUsername(dbProperties.getUser_name()); //
	 * LOGGER.info("Username got set"); // //
	 * bds.setPassword(dbProperties.getPassword()); //
	 * LOGGER.info("Password got set"); //// bds.setInitialSize(10); // default is 0
	 * //// bds.setMaxActive(10); // default is 8 //// bds.setMinIdle(5); // default
	 * is 0 //// bds.setMaxIdle(10); // default 8 ////
	 * bds.setMaxOpenPreparedStatements(100); // default is -1 // //
	 * LOGGER.info("bds.getInitialSize()= " + bds.getInitialSize()); //
	 * LOGGER.info("bds.getMaxActive()" + bds.getMaxActive()); //
	 * LOGGER.info("bds.getMinIdle()= "+bds.getMinIdle()); //
	 * LOGGER.info("bds.getMaxIdle()= "+bds.getMaxIdle()); //
	 * LOGGER.info("bds.getMaxOpenPreparedStatements()= "+bds.
	 * getMaxOpenPreparedStatements()); // LOGGER.info("bds=" + bds); conn =
	 * bds.getConnection(); LOGGER.info("conn=" + conn);
	 * LOGGER.info("conn.getClientInfo()=" + conn.getClientInfo());
	 * 
	 * } catch (SQLException e) { e.printStackTrace(); } return conn; }
	 * 
	 * // public static void main(String[] args) { // ConnectSbmDB db = new
	 * ConnectSbmDB(); // System.out.println(db.getConnection()); // }
	 */
}
