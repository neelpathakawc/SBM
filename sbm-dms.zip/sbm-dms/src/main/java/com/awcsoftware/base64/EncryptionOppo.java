/**
 * 
 */
package com.awcsoftware.base64;

import java.util.Base64;

import javax.xml.bind.DatatypeConverter;

import org.apache.log4j.Logger;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

/**
 * @author Shuaib
 *
 */

//@Lazy
@Component
public class EncryptionOppo {
	final static Logger LOGGER = Logger.getLogger(EncryptionOppo.class);

	private byte[] decodedData;

	Byte[] encodedData;

	public Byte[] encodeData(byte[] data) {
		LOGGER.info("Entered encodeData()");
		// encodedData = DatatypeConverter.printBase64Binary(data).getBytes();
		int i = 0;
		encodedData = new Byte[Base64.getEncoder().encode(data).length];
		// Associating Byte array values with bytes. (byte[] to Byte[])
		for (byte b : Base64.getEncoder().encode(data))
			encodedData[i++] = b; // Autoboxing.
		LOGGER.info("encodedData" + encodedData);
		return encodedData;
	}

	public byte[] decodeData(byte[] data) {
		// decodedData = DatatypeConverter.parseBase64Binary(new String(data));
		decodedData = Base64.getDecoder().decode(data);
		return decodedData;
	}
}
