package com.awcsoftware.validations;

import java.io.File;

import org.apache.log4j.Logger;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.awcsoftware.dms.dto.BaseData;
import com.awcsoftware.dms.dto.Document;

public class DocumentDataValidator implements Validator {
	final static Logger LOGGER = Logger.getLogger(DocumentDataValidator.class);

	private static String getFileExtension(File file) {
		LOGGER.debug("Entered getFileExtension");
		String fileName = file.getName();
		if (fileName.lastIndexOf(".") != -1 && fileName.lastIndexOf(".") != 0) {
			return fileName.substring(fileName.lastIndexOf(".") + 1);
		} else {
			return "";
		}

	}

	@Override
	public boolean supports(Class<?> clazz) {
		return BaseData.class.isAssignableFrom(clazz);
		// return DocumentData.class.equals(clazz);

	}

	@Override
	public void validate(Object target, Errors errors) {
		LOGGER.info("Entered validate ");
		BaseData bd=(BaseData)target;

			Document pdd=(Document) target;
			if (checkInputString(pdd.getCifId())) {
				errors.rejectValue("name", "name.empty");
			}

		/*
		 * Changing a number of letters to their capital forms to bypass case sensitive
		 * rules (e.g. “file.aSp” or “file.PHp3”). Solution: Use equalsIgnoreCase rather
		 * than equals to do comparison check.
		 */
		// Upload .html file containing script - victim experiences Cross-site Scripting
		// (XSS)

		File file = new File(bd.getDocN());
		if (getFileExtension(file).isEmpty()) {
			errors.reject("docN", "Uploading File(s)  must have an extension.");
		} else if ("exe".equalsIgnoreCase(getFileExtension(file))) {
			errors.reject("docN", ".exe file is restricted, it could not get uploaded.");
		} else if ("rar".equalsIgnoreCase(getFileExtension(file))) {
			errors.reject("docN", ".rar file is restricted, it could not get uploaded.");
		} else if ("html".equalsIgnoreCase(getFileExtension(file)) || "htm".equalsIgnoreCase(getFileExtension(file))) {
			errors.rejectValue("docN", ".html file is restricted, it could not get uploaded.");
		}

//In Apache, a php file might be executed using the double extension technique such as “file.php.jpg” when “.jpg” is allowed.

//		else if (getFileExtension(file).isEmpty()) {
//
//		} else if (!PNG_MIME_TYPE.equalsIgnoreCase(file.getContentType())) {
//			errors.rejectValue("file", "upload.invalid.file.type");
//		}
//
//		else if (file.getSize() > TEN_MB_IN_BYTES) {
//			errors.rejectValue("file", "upload.exceeded.file.size");
//		}
		}

	private boolean checkInputString(String input) {
		return (input == null || input.trim().length() == 0);
	}

}
