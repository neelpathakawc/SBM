package com.awcsoftware.exception;

/**
 * @author Shuaib
 *
 */
public class SbmException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String message = null;

	public SbmException(String message) {
		super(message);
		this.message = message;
	}

	public SbmException() {
		super();
	}

	@Override
	public String toString() {
		return message;
	}

	@Override
	public String getMessage() {
		// TODO Auto-generated method stub
		return message;
	}

}
