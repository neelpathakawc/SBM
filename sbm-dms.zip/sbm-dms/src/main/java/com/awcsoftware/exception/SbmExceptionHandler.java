
package com.awcsoftware.exception;

import java.time.LocalDateTime;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;

import org.springframework.validation.FieldError;
import org.springframework.validation.annotation.Validated;
import org.apache.log4j.Logger;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingRequestHeaderException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@ControllerAdvice(annotations = Validated.class)
public class SbmExceptionHandler extends ResponseEntityExceptionHandler {
	final static Logger LOGGER = Logger.getLogger(SbmExceptionHandler.class);

	@ExceptionHandler(value = { SbmException.class })
	public ResponseEntity<Object> handleSpecificException(SbmException ex, WebRequest request) {

		String errorMessageDescription = ex.getLocalizedMessage();
		LOGGER.debug("errorMessageDescription= "+errorMessageDescription);
		if (errorMessageDescription == null) {
			errorMessageDescription = ex.toString();
		}
		if(errorMessageDescription.equals("Invalid Session Id")) {
			SbmApiResponse errorMessage = new SbmApiResponse(LocalDateTime.now(), errorMessageDescription, 400);
			return new ResponseEntity<>(errorMessage, new HttpHeaders(), HttpStatus.BAD_REQUEST);
		}

		SbmApiResponse errorMessage = new SbmApiResponse(LocalDateTime.now(), errorMessageDescription, 500);
		return new ResponseEntity<>(errorMessage, new HttpHeaders(), HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	@ExceptionHandler(value = { MissingRequestHeaderException.class })
	public ResponseEntity<Object> handleSpecificException(MissingRequestHeaderException ex, WebRequest request) {

		String errorMessageDescription = ex.getLocalizedMessage();
		LOGGER.debug("errorMessageDescription= "+errorMessageDescription);
		if (errorMessageDescription == null) {
			errorMessageDescription = ex.toString();
		}
		SbmApiResponse errorMessage = new SbmApiResponse(LocalDateTime.now(), errorMessageDescription, 500);
		return new ResponseEntity<>(errorMessage, new HttpHeaders(), HttpStatus.BAD_REQUEST);
	}
	
	@ExceptionHandler
	public ResponseEntity<Object> handle(ConstraintViolationException exception) {

		/*
		 * List<String> errors =
		 * exception.getConstraintViolations().stream().map(this::toString)
		 * .collect(Collectors.toList());
		 * 
		 * return new ResponseEntity<Object>(new SbmApiResponse(LocalDateTime.now(),
		 * errors), 400); }
		 * 
		 * String Formatter;
		 * 
		 * private String toString(ConstraintViolation<?> violation) { return
		 * Formatter.format("{} {}: {}", violation.getRootBeanClass().getName(),
		 * violation.getPropertyPath(), violation.getMessage()); }
		 * 
		 * public static class ErrorResponseBody { private String message; private
		 * List<String> errors; }
		 */

	Set<ConstraintViolation<?>> errorSet = exception.getConstraintViolations();
	Iterator<ConstraintViolation<?>> it = errorSet.iterator();
	StringBuilder errorMessageDescription = new StringBuilder();

	while(it.hasNext())
	{
		ConstraintViolation<?> violation = (ConstraintViolation<?>) it.next();
		LOGGER.debug(violation.getRootBeanClass().getName());
		LOGGER.debug(violation.getPropertyPath());
		LOGGER.debug(violation.getMessage());
		errorMessageDescription.append(violation.getMessage() + ", ");
	}

	SbmApiResponse errorMessage = new SbmApiResponse(LocalDateTime.now(), errorMessageDescription.toString(),
			400);return new ResponseEntity<>(errorMessage,new HttpHeaders(),HttpStatus.BAD_REQUEST);
	}

	@Override
	protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex,
			HttpHeaders headers, HttpStatus status, WebRequest request) {
		LOGGER.debug("ex.getBindingResult().getFieldErrors()= " + ex.getBindingResult().getFieldErrors());
		List<FieldError> fieldErrors = ex.getBindingResult().getFieldErrors();
		StringBuilder errorMessageDescription = new StringBuilder();

		for (FieldError error : fieldErrors) {
			LOGGER.debug(error.getDefaultMessage());
			errorMessageDescription.append(error.getDefaultMessage() + ", ");
		}

		SbmApiResponse errorMessage = new SbmApiResponse(LocalDateTime.now(), errorMessageDescription.toString(),
				400);
		return new ResponseEntity<>(errorMessage, new HttpHeaders(), HttpStatus.BAD_REQUEST);
	}
}
