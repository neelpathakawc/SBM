package com.awcsoftware.exception;
//package com.awcsoftware.exception;
//
//import java.time.LocalDateTime;
//import java.util.Iterator;
//import java.util.Set;
//import javax.validation.ConstraintViolation;
//import javax.validation.ConstraintViolationException;
//
//import org.apache.log4j.Logger;
//import org.springframework.http.HttpHeaders;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//import org.springframework.validation.annotation.Validated;
//import org.springframework.web.bind.MethodArgumentNotValidException;
//import org.springframework.web.bind.annotation.ControllerAdvice;
//import org.springframework.web.bind.annotation.ExceptionHandler;
//import org.springframework.web.context.request.WebRequest;
//
//@ControllerAdvice(annotations = Validated.class)
//public class ValidatedExceptionHandler {
//	final static Logger LOGGER = Logger.getLogger(ValidatedExceptionHandler.class);
//
//	@ExceptionHandler
//	public ResponseEntity<Object> handle(ConstraintViolationException exception) {
////		List<String> errors = exception.getConstraintViolations().stream().map(this::toString)
////				.collect(Collectors.toList());
//		Set<ConstraintViolation<?>> errorSet = exception.getConstraintViolations();
//		Iterator<ConstraintViolation<?>> it = errorSet.iterator();
//		StringBuilder errorMessageDescription = new StringBuilder();
//
//		while (it.hasNext()) {
//			ConstraintViolation<?> violation = (ConstraintViolation<?>) it.next();
//			LOGGER.debug(violation.getRootBeanClass().getName());
//			LOGGER.debug(violation.getPropertyPath());
//			LOGGER.debug(violation.getMessage());
//			errorMessageDescription.append(violation.getMessage() + ", ");
//		}
//
//		SbmApiResponse errorMessage = new SbmApiResponse(LocalDateTime.now(), errorMessageDescription.toString(),
//				400);
//		return new ResponseEntity<>(errorMessage, new HttpHeaders(), HttpStatus.BAD_REQUEST);
//	}
//
//	/*
//	 * private String toString(ConstraintViolation<?> violation) { return
//	 * Forma.format("{} {}: {}", violation.getRootBeanClass().getName(),
//	 * violation.getPropertyPath(), violation.getMessage()); }
//	 * 
//	 * public static class ErrorResponseBody { private String message; private
//	 * List<String> errors;
//	 * 
//	 * }
//	 */
//
//}