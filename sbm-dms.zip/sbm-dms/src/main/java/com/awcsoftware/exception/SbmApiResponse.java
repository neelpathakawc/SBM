package com.awcsoftware.exception;

import java.time.LocalDateTime;

public class SbmApiResponse {
	LocalDateTime timestamp;
	String message;
	int status;

	public SbmApiResponse() {
		// TODO Auto-generated constructor stub
	}
	

	public SbmApiResponse(LocalDateTime timestamp, String message) {
		super();
		this.timestamp = timestamp;
		this.message = message;
	}


	public SbmApiResponse(LocalDateTime timestamp, String message, int status) {
		super();
		this.timestamp = timestamp;
		this.message = message;
		this.status = status;
	}
	
	

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public LocalDateTime getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(LocalDateTime timestamp) {
		this.timestamp = timestamp;
	}
}
