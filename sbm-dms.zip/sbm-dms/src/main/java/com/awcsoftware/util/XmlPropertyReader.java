package com.awcsoftware.util;

import java.io.StringReader;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

public class XmlPropertyReader {
	
	public static String getPropertyValuefromXml(String xmlString, String tagName, String property) {
		String pValue = "";
		try {
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder builder = dbFactory.newDocumentBuilder();
			InputSource is = new InputSource(new StringReader(xmlString));
			Document doc = builder.parse(is);
			doc.getDocumentElement().normalize();
			System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
			NodeList flowList = doc.getElementsByTagName(tagName);
			for (int i = 0; i < flowList.getLength(); i++) {
				NodeList childList = flowList.item(i).getChildNodes();
				for (int j = 0; j < childList.getLength(); j++) {
					Node childNode = childList.item(j);
					if (property.equals(childNode.getNodeName())) {
						System.out.println(childList.item(j).getTextContent().trim());
						pValue = childList.item(j).getTextContent().trim();
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return pValue;

	}

}
