package com.awcsoftware.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotEmpty;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.CacheControl;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BeanPropertyBindingResult;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.awcsoftware.dms.api.DmsApi;
import com.awcsoftware.dms.dto.BaseData;
import com.awcsoftware.dms.dto.BinaryData;
import com.awcsoftware.dms.dto.Document;
import com.awcsoftware.dms.dto.DownloadMetaData;
import com.awcsoftware.dms.dto.UploadResponse;
import com.awcsoftware.dms.dto.UserData;
import com.awcsoftware.dms.dto.VersionContent;
import com.awcsoftware.dms.dto.VersionRequest;
import com.awcsoftware.dms.dto.VersionResponse;
import com.awcsoftware.dms.rest.service.DownloadService;
import com.awcsoftware.dms.rest.service.SbmDBOperations;
import com.awcsoftware.dms.rest.service.UploadService;
import com.awcsoftware.dms.rest.service.VersionService;
import com.awcsoftware.exception.SbmException;
import com.awcsoftware.validations.DocumentDataValidator;

@RestController
@RequestMapping("/sbm/dms-webapi")
public class SbmController {
	final static Logger LOGGER = Logger.getLogger(SbmController.class);
	@Autowired
	private UploadService uploadService;
	@Autowired
	private DownloadService downloadService;
	private SbmDBOperations dbOps;
	HttpHeaders headers;

	@Autowired
	private DmsApi dmsApi;

	@Autowired
	private VersionService vs;

	@Autowired
	public SbmController(SbmDBOperations dbOps) {
		super();
		this.dbOps = dbOps;
	}

	@GetMapping
	String getDmsStatus() {
		return "SBM Web-Server is up & running !";
	}

	@RequestMapping(value = "/get-sessionid", method=RequestMethod.POST)
	public ResponseEntity<String> getSessionId(@Valid @RequestBody UserData userData) {
		LOGGER.info("Inside getSessionId()"+userData.toString());
		return new ResponseEntity<String>(dmsApi.connect(userData), HttpStatus.OK);
	}

	/**
	 * 
	 * @param docId
	 * @returns the latest Image Index of the document
	 */
	@GetMapping("/document-getById/{docId}")
	public VersionContent getDocumentIndex(@PathVariable int docId) {
		LOGGER.info("Entered getDocumentIndex method");
		return dbOps.getVersionData(docId);
	}

	@PutMapping("/document-createVersion")
	public VersionResponse createVersion(
			@RequestHeader @NotEmpty(message = "Session Id Header could not be empty!") @Digits(fraction = 0, integer = 10, message = "Session Id should be in digits only") String sessionId,
			@RequestBody VersionRequest vd) {
		LOGGER.info("Entered createVersion method");
		return vs.versionService(sessionId, vd);
	}

	/*
	 * @GetMapping(value = "/document-get", produces =
	 * MediaType.APPLICATION_JSON_VALUE) ResponseEntity<ArrayList<BinaryData>>
	 * getDocument(
	 * 
	 * @RequestHeader @NotEmpty(message =
	 * "Session Id Header could not be empty!") @Digits(fraction = 0, integer = 10,
	 * message = "Session Id should be in digits only") String sessionId,
	 * 
	 * @RequestHeader @NotEmpty(message = "documents Id Header could not be empty!")
	 * String documents) { LOGGER.info("Entered getDocument method"); if
	 * (documents.contains(" ")) { throw new
	 * SbmException("There should be no space in document list each separated by a comma!"
	 * ); } ArrayList<BinaryData> al = downloadService.downloadDocuments(sessionId,
	 * documents); BinaryData bd = al.get(0); LOGGER.debug("binary data= " + bd +
	 * "\tbd.getData()= " + bd.getData()); LOGGER.debug("Headers going to set....");
	 * headers = new HttpHeaders();
	 * headers.setCacheControl(CacheControl.noCache().getHeaderValue());
	 * headers.setCacheControl(CacheControl.noStore().getHeaderValue()); return new
	 * ResponseEntity<>(al, headers, HttpStatus.OK); }
	 */

	@GetMapping(value = "/document-download", produces = MediaType.APPLICATION_JSON_VALUE)
	ResponseEntity<ArrayList<BinaryData>> documentDownload(
			@RequestHeader @NotEmpty(message = "Session Id Header could not be empty!") @Digits(fraction = 0, integer = 10, message = "Session Id should be in digits only") String sessionId,
			@RequestBody DownloadMetaData dmList) {
		LOGGER.info("Entered getDocument method");
		ArrayList<BinaryData> al = downloadService.downloadDocuments(sessionId, dmList);
		BinaryData bd = al.get(0);
		LOGGER.debug("binary data= " + bd + "\tbd.getData()= " + bd.getData());
		LOGGER.debug("Headers going to set....");
		headers = new HttpHeaders();
		headers.setCacheControl(CacheControl.noCache().getHeaderValue());
		headers.setCacheControl(CacheControl.noStore().getHeaderValue());
		return new ResponseEntity<>(al, headers, HttpStatus.OK);
	}

	@PostMapping("/validateSession")
	public String validateSessionid(
			@RequestHeader @NotEmpty(message = "Session Id Header could not be empty!") @Digits(fraction = 0, integer = 10, message = "Session Id should be in digits only") String sessionId) {
		LOGGER.info("Entered validateSessionid");
		return "" + dbOps.validateSessionId(sessionId);
	}

	@PostMapping(value = "/documentupload", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<UploadResponse> uploadDocument(@Valid @RequestBody ArrayList<Document> dd,
			@RequestHeader @NotEmpty(message = "Session Id Header could not be empty!") @Digits(fraction = 0, integer = 10, message = "Session Id should be in digits only") String sessionId,
			BindingResult bindingResult) throws MethodArgumentNotValidException {
		LOGGER.info("Entered uploadDocument() -> dd.size= " + dd.size());
		for (int i = 0; i < dd.size(); i++) {
			Object o = dd.get(i);
			BeanPropertyBindingResult errors = new BeanPropertyBindingResult(o, String.format("o[%d]", i));
			DocumentDataValidator validator = new DocumentDataValidator();
			validator.validate(o, errors);
			LOGGER.debug(bindingResult);
			LOGGER.debug("errors= " + errors);
			LOGGER.debug(errors.getAllErrors());
			if (errors.hasErrors()) {
				List<ObjectError> fieldErrors = errors.getAllErrors();
				LOGGER.debug(fieldErrors);
				StringBuilder errorMessage = new StringBuilder();
				for (ObjectError error : fieldErrors) {
					LOGGER.debug("error.getDefaultMessage()= " + error.getDefaultMessage());
					errorMessage.append(error.getDefaultMessage() + ", ");
				}
				throw new SbmException(errorMessage.toString()); //
				// bindingResult.addAllErrors(errors);
			}
		}
		return uploadService.uploadDocument(dd, sessionId);
	}

}
