package com.awcsoftware.newgen.beans.config;
//package com.awcsoftware.newgen.beans.config;
//
//public class MessageConverterConfig {
//	
//	configureMessageConverters(
//
//}
/*
 * @Data
 * 
 * @AllArgsConstructor public class SampleData { private String[] data; }
 */