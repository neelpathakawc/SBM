package com.awcsoftware.newgen.beans.config;

import org.apache.commons.dbcp.BasicDataSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.newgen.dmsapi.DMSCallBroker;
import com.newgen.dmsapi.DMSInputXml;
import com.newgen.dmsapi.DMSXmlResponse;
import ISPack.ISUtil.JPDBRecoverDocData;
import ISPack.ISUtil.JPISIsIndex;

@Configuration
public class NewgenBeansConfig {
	@Bean
	public DMSInputXml getDMSInputXml() {
		return new DMSInputXml();
	}

	@Bean
	public DMSXmlResponse getDMSXmlResponse() {
		return new DMSXmlResponse();
	}

	@Bean
	public DMSCallBroker getDmsCallBroker() {
		return new DMSCallBroker();
	}

	@Bean
	public JPDBRecoverDocData getJPDBRecoverDocData() {
		return new JPDBRecoverDocData();
	}

	@Bean
	public JPISIsIndex getJPISIsIndex() {
		return new JPISIsIndex();
	}

	@Bean
	public BasicDataSource getBasicDataSource() {
		return new BasicDataSource();
	}
}
