package com.awcsoftware;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import com.awcsoftware.spring.data.jpa.DBProperties;


@EnableConfigurationProperties(DBProperties.class)
@SpringBootApplication
public class SbmDmsApplication {

	public static void main(String[] args) {
		SpringApplication.run(SbmDmsApplication.class, args);
	}
}
