/**
 * 
 */
package com.awcsoftware.dms.dto;

import java.util.Arrays;

/**
 * @author Shuaib
 *
 */
public class BinaryData {
	/**
	 * 
	 */
	private int imageIndex;
	private Byte[] data;
	private String error;

	public BinaryData() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param imageIndex
	 * @param data
	 */
	public BinaryData(int imageIndex, Byte[] data, String error) {
		super();
		this.imageIndex = imageIndex;
		this.data = data;
		this.error = error;
	}

	/**
	 * @return the imageIndex
	 */
	public int getimageIndex() {
		return imageIndex;
	}

	/**
	 * @param imageIndex the imageIndex to set
	 */
	public void setimageIndex(int imageIndex) {
		this.imageIndex = imageIndex;
	}

	/**
	 * @return the data
	 */
	public Byte[] getData() {
		return data;
	}

	public void setData(Byte[] data2) {
		this.data = data2;
	}

	/**
	 * @return the error
	 */
	public String getError() {
		return error;
	}

	/**
	 * @param error the error to set
	 */
	public void setError(String error) {
		this.error = error;
	}
	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#hashCode()
	 */

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + Arrays.hashCode(data);
		result = prime * result + ((error == null) ? 0 : error.hashCode());
		result = prime * result + imageIndex;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		BinaryData other = (BinaryData) obj;
		if (!Arrays.equals(data, other.data))
			return false;
		if (error == null) {
			if (other.error != null)
				return false;
		} else if (!error.equals(other.error))
			return false;
		if (imageIndex != other.imageIndex)
			return false;
		return true;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "BinaryData [imageIndex=" + imageIndex + ", data.size=" + data.length + ", error=" + error + "]";
	}

}
