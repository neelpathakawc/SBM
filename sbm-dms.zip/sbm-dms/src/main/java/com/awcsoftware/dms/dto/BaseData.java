package com.awcsoftware.dms.dto;

import javax.validation.constraints.NotEmpty;

public class BaseData {
	@NotEmpty(message = "Please provide Document Name!")
	private String docN;
	@NotEmpty(message = "Please provide Document Type!")
	private String docType;
	@NotEmpty(message = "Please provide Document Data!")
	protected byte[] binData;

	/*
	 * public BaseData() { System.out.
	 * println("#############################BaseData Constructor called #################################"
	 * ); }
	 */
	public BaseData(@NotEmpty(message = "Please provide Document Name!") String docN,
			@NotEmpty(message = "Please provide Document Type!") String docType,
			@NotEmpty(message = "Please provide Document Data!") byte[] binData) {
		super();
		this.docN = docN;
		this.docType = docType;
		this.binData = binData;
	}

	public String getDocN() {
		return docN;
	}

	public void setDocN(String docN) {
		this.docN = docN;
	}

	public String getDocType() {
		return docType;
	}

	public void setDocType(String docType) {
		this.docType = docType;
	}

	public byte[] getBinData() {
		return binData;
	}

	public void setBinData(byte[] binData) {
		this.binData = binData;
	}
}
