package com.awcsoftware.dms.api;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

@Component
@Primary
public class DmsProperties {

	@Value("${server.ip}")
	private String serverIP;

	@Value("${server.cabinet}")
	private String cabinateName;
	
	@Value("${server.dmsRootFolder}")
	private int dmsRootFolder;
	
	public String getServerIP() {
		return serverIP;
	}

	public void setServerIP(String serverIP) {
		this.serverIP = serverIP;
	}

	public String getCabinateName() {
		return cabinateName;
	}

	public void setCabinateName(String cabinateName) {
		this.cabinateName = cabinateName;
	}

	public int getDmsRootFolder() {
		return dmsRootFolder;
	}

	public void setDmsRootFolder(int dmsRootFolder) {
		this.dmsRootFolder = dmsRootFolder;
	}
	
}
