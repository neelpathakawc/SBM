package com.awcsoftware.dms.rest.service;
/*
 * package com.awcsoftware.dms.rest.service;
 * 
 * import java.sql.Connection; import java.sql.DatabaseMetaData; import
 * java.sql.SQLException;
 * 
 * import javax.sql.DataSource;
 * 
 * import org.springframework.beans.factory.annotation.Autowired;
 * 
 * import com.awcsoftware.spring.data.jpa.ConnectSbmDB;
 * 
 * public class DBServiceCalls {
 * 
 * private ConnectSbmDB pdb;
 * 
 * @Autowired private DataSource ds;
 * 
 * public DBServiceCalls() { pdb = new ConnectSbmDB(ds); }
 * 
 * public String getMetaData() { Connection conn = pdb.getConnection(); String
 * datax = null; try { DatabaseMetaData dbmd = conn.getMetaData(); datax =
 * dbmd.getDatabaseProductName(); } catch (SQLException e) {
 * e.printStackTrace(); } finally { try { conn.close(); } catch (SQLException e)
 * { // TODO Auto-generated catch block e.printStackTrace(); } } return datax; }
 * 
 * public static void main(String[] args) { DBServiceCalls cc = new
 * DBServiceCalls(); System.out.println(cc.getMetaData()); } }
 */