package com.awcsoftware.dms.api;
/*
 * package com.awcsoftware.dms.api;
 * 
 * import org.apache.log4j.Logger;
 * 
 * import com.opposfe.base64.EncryptionOppo; import
 * com.awcsoftware.bytes.BytesConvertion; import com.awcsoftware.dms.dto.DocumentData;
 * 
 * public class Test { final static Logger logger =
 * Logger.getLogger(UploadDocument.class);
 * 
 * public static void main(String[] args) { logger.info("Inside Main of Test");
 * BytesConvertion bc = new BytesConvertion(); EncryptionOppo ep = new
 * EncryptionOppo();
 * logger.info("BytesConvertion, EncryptionOppo Object Created"); byte[] bv =
 * ep.encodeData(bc.
 * convertToByteData("D:\\Oppo\\Oppo_Images\\CreatePassword Screen.png"));
 * logger.info("encodeData() called"); UploadDocument ud = new UploadDocument();
 * for (int i = 0; i < 2; i++) { logger.info("Inside For Loop i= " + i);
 * DocumentData dd = new DocumentData("999", "99", "9", "pdf", "shuaib-PF",
 * "LO", bv); logger.info("DocumentData dd= " + dd); ud.upload(dd,
 * "-1967257414"); logger.info("ud.upload()"); } } }
 */