/**
 * 
 */
package com.awcsoftware.dms.dto;

/**
 * @author mflacc
 *
 */
public class VersionResponse {
	private String status;
	private int docId;
	private float verNo;
	private int documentIndex;
	private String comment;

	/**
	 * 
	 */
	public VersionResponse() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param status
	 * @param docId
	 */
	public VersionResponse(String status, int docId, float verNo, int documentIndex, String comment) {
		super();
		this.status = status;
		this.docId = docId;
		this.verNo = verNo;
		this.documentIndex = documentIndex;
		this.comment = comment;
	}

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * @return the docId
	 */
	public int getDocId() {
		return docId;
	}

	/**
	 * @param docId the docId to set
	 */
	public void setDocId(int docId) {
		this.docId = docId;
	}

	/**
	 * @return the verNo
	 */
	public float getVerNo() {
		return verNo;
	}

	/**
	 * @param verNo the verNo to set
	 */
	public void setVerNo(float verNo) {
		this.verNo = verNo;
	}

	/**
	 * @return the documentIndex
	 */
	public int getDocumentIndex() {
		return documentIndex;
	}

	/**
	 * @param documentIndex the documentIndex to set
	 */
	public void setDocumentIndex(int documentIndex) {
		this.documentIndex = documentIndex;
	}

	/**
	 * @return the comment
	 */
	public String getComment() {
		return comment;
	}

	/**
	 * @param comment the comment to set
	 */
	public void setComment(String comment) {
		this.comment = comment;
	}
	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#hashCode()
	 */

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((comment == null) ? 0 : comment.hashCode());
		result = prime * result + docId;
		result = prime * result + documentIndex;
		result = prime * result + ((status == null) ? 0 : status.hashCode());
		result = prime * result + Float.floatToIntBits(verNo);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		VersionResponse other = (VersionResponse) obj;
		if (comment == null) {
			if (other.comment != null)
				return false;
		} else if (!comment.equals(other.comment))
			return false;
		if (docId != other.docId)
			return false;
		if (documentIndex != other.documentIndex)
			return false;
		if (status == null) {
			if (other.status != null)
				return false;
		} else if (!status.equals(other.status))
			return false;
		if (Float.floatToIntBits(verNo) != Float.floatToIntBits(other.verNo))
			return false;
		return true;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "VersionResponse [status=" + status + ", docId=" + docId + ", verNo=" + verNo + ", documentIndex="
				+ documentIndex + ", comment=" + comment + "]";
	}

}
