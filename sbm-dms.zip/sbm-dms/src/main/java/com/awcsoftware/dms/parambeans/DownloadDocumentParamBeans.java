package com.awcsoftware.dms.parambeans;
/**
 * 
 */
/*
 * package com.awcsoftware.dms.parambeans;
 * 
 * 
 *//**
	 * @author Shuaib
	 *
	 */
/*
 * public class DownloadDocumentParamBeans { //
 * private @HeaderParam("sessionid") String sessionid; //
 * private @HeaderParam("documents") String documents; private String sessionId;
 * private String documents;
 * 
 *//**
	 * @param sessionid : The session required to validate user session before
	 *                  uploading documents.
	 * @param documents :
	 */
/*
 * public DownloadDocumentParamBeans(String sessionid, String documents) {
 * super(); this.sessionId = sessionid; this.documents = documents; }
 *//**
	 * @return the sessionid
	 */
/*
 * public String getSessionid() { return sessionId; }
 *//**
	 * @param sessionid the sessionid to set
	 */
/*
 * public void setSessionid(String sessionid) { this.sessionId = sessionid; }
 *//**
	 * @return the documents
	 */
/*
 * public String getDocuments() { return documents; }
 *//**
	 * @param documents the documents to set
	 *//*
		 * public void setDocuments(String documents) { this.documents = documents; }
		 * (non-Javadoc)
		 * 
		 * @see java.lang.Object#hashCode()
		 * 
		 * @Override public int hashCode() { final int prime = 31; int result = 1;
		 * result = prime * result + ((documents == null) ? 0 : documents.hashCode());
		 * result = prime * result + ((sessionId == null) ? 0 : sessionId.hashCode());
		 * return result; } (non-Javadoc)
		 * 
		 * @see java.lang.Object#equals(java.lang.Object)
		 * 
		 * @Override public boolean equals(Object obj) { if (this == obj) return true;
		 * if (obj == null) return false; if (getClass() != obj.getClass()) return
		 * false; DownloadDocumentParamBeans other = (DownloadDocumentParamBeans) obj;
		 * if (documents == null) { if (other.documents != null) return false; } else if
		 * (!documents.equals(other.documents)) return false; if (sessionId == null) {
		 * if (other.sessionId != null) return false; } else if
		 * (!sessionId.equals(other.sessionId)) return false; return true; }
		 * (non-Javadoc)
		 * 
		 * @see java.lang.Object#toString()
		 * 
		 * @Override public String toString() { return
		 * "DownloadDocumentParamBeans [sessionid=" + sessionId + ", documents=" +
		 * documents + "]"; }
		 * 
		 * }
		 */