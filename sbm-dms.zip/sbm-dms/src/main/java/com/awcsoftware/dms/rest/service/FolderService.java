package com.awcsoftware.dms.rest.service;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.awcsoftware.dms.api.DmsApi;
import com.awcsoftware.dms.dto.FolderDetails;


@Service
public class FolderService {
	private final static Logger LOGGER = Logger.getLogger(FolderService.class);
	private DmsApi dmsApi;

	@Autowired
	public FolderService(DmsApi dmsApi) {
		super();
		this.dmsApi = dmsApi;
	}

	public String addFolder(String folderName, String sessionId) {
		LOGGER.info("Entered addFolder()");
		if (isFolderExist(folderName, "Oppo")) {
//			return dmsApi.createFolder(folderName, sessionId);
		} else {
			return "Folder already exist!";
		}
		// Remove it too
		return null;

	}

	public Boolean isFolderExist(String folderName, String parentFolderName) {
		return true;

	}

}
