/**
 * 
 */

package com.awcsoftware.dms.api;

import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.awcsoftware.base64.EncryptionOppo;
import com.awcsoftware.bytes.BytesConvertion;
import com.awcsoftware.dms.dto.VersionRequest;
import com.awcsoftware.dms.dto.VersionResponse;
import com.awcsoftware.spring.data.jpa.ConnectSbmDB;
import com.newgen.dmsapi.DMSXmlResponse;

import ISPack.CPISDocumentTxn;
import ISPack.ISUtil.JPDBRecoverDocData;
import ISPack.ISUtil.JPISException;
import ISPack.ISUtil.JPISIsIndex;

/**
 * @author Shuaib
 *
 */

@Service
public class DocumentVersioning {
	private JPDBRecoverDocData docDBData;
	private JPISIsIndex newIsIndex;
	final static Logger LOGGER = Logger.getLogger(DocumentVersioning.class);
	private DmsApi dApi;
	private BytesConvertion bc;
	private String fileLocation = "C:\\Newgen\\Server\\LocalRepository\\";
	private EncryptionOppo em;
	private ArrayList<Object> al = new ArrayList<>();
	private DMSXmlResponse response; //
	private String docIndex;
	// private int docIndex1; private String isIndexNew;
	private String isIndex1;
	private DmsProperties pp;
	private ConnectSbmDB dbconn;
	private String isIndexNew;

	/**
	* 
	*/

	@Autowired
	public DocumentVersioning(JPDBRecoverDocData docDBData, JPISIsIndex newIsIndex, EncryptionOppo em,
			BytesConvertion bc, DmsApi dApi, DMSXmlResponse response, DmsProperties pp, ConnectSbmDB dbconn) {
		this.docDBData = docDBData;
		this.newIsIndex = newIsIndex;
		this.em = em;
		this.bc = bc;
		this.dApi = dApi;
		this.response = response;
		this.pp = pp;
		this.dbconn = dbconn;
	}

	public VersionResponse checkin(VersionRequest req, String sessionId) {
		LOGGER.info("Entered checkin method");
		VersionResponse vr = new VersionResponse();
		// Extracted From Request
		int docId = req.getDocId();
		byte[] data = req.getData();
		String ext = req.getExt();
		String docType = "";
		String comment = req.getComment();
		// Extraction Closes
		ArrayList dbData = getIsIndex(docId);
		Integer dummy = (Integer) dbData.get(0);
		if (dummy == 0) {
			LOGGER.debug("Document Does Not Exist");
			vr = new VersionResponse("0", 0, 0.0f, 0, "Document Does Not Exist");
		} else {
			try {
				bc.writeByteArraysToFile(fileLocation + dbData.get(1) + "." + ext, em.decodeData(data));
				// String sessionId = capi.getSessionId().get(0);
				File f = new File(fileLocation + dbData.get(1) + "." + ext);
				if (ext.equalsIgnoreCase("jpg") || ext.equalsIgnoreCase("JPEG") || ext.equalsIgnoreCase("png")
						|| ext.equalsIgnoreCase("tiff") || ext.equalsIgnoreCase("bmp") || ext.equalsIgnoreCase("png")) {
					LOGGER.info("Doctype is Image");
					docType = "I";
				} else if (ext.equalsIgnoreCase("mp4") || ext.equalsIgnoreCase("vob") || ext.equalsIgnoreCase("mkv")
						|| ext.equalsIgnoreCase("webm") || ext.equalsIgnoreCase("avi")) {
					LOGGER.info("Doctype is Video");
					docType = "V";
				} else if (ext.equalsIgnoreCase("pdf")) {
					docType = testPdf(fileLocation + dbData.get(1) + "." + ext);
					if (docType == "I") {
						LOGGER.info("Doctype is Image");
					} else if (docType == "N") {
						LOGGER.info("Doctype is Others");
					}
				} else {
					LOGGER.info("Doctype is Others");
					docType = "N";
				}
				try {
					// Step-1 of 2 - Add document into the Image Server. (Physical storage of
					// document)
					CPISDocumentTxn.AddDocument_MT(null, pp.getServerIP(), Short.parseShort("3333"),
							pp.getCabinateName(), Short.parseShort("1"), fileLocation + dbData.get(1) + "." + ext,
							docDBData, "1", newIsIndex);

					// docIndex1 = newIsIndex.m_nDocIndex;
					isIndex1 = newIsIndex.m_nDocIndex + "#" + newIsIndex.m_sVolumeId;
					isIndexNew = newIsIndex.m_nDocIndex + "#" + newIsIndex.m_sVolumeId;
					// logger.info("DocIndex :" + docIndex1 + " /isIndex :" + isIndex1);
					String checkoutinputXml = "<?xml version=\"1.0\"?><NGOCheckinCheckoutExt_Input><Option>NGOCheckinCheckoutExt</Option><CabinetName>"
							+ pp.getCabinateName() + "</CabinetName><UserDBId>" + sessionId
							+ "</UserDBId><CurrentDateTime></CurrentDateTime><LimitCount>1000</LimitCount><CheckInOutFlag>Y</CheckInOutFlag><SupAnnotVersion>N</SupAnnotVersion><Documents><Document><DocumentIndex>"
							+ dbData.get(0) + "</DocumentIndex><ISIndex>" + isIndexNew
							+ "</ISIndex></Document></Documents></NGOCheckinCheckoutExt_Input>\r\n" + "";
					LOGGER.info(checkoutinputXml);
					response.setXmlString(dApi.callBroker(checkoutinputXml));
					LOGGER.info(response.strXML);
					if (Integer.parseInt(response.getVal("Status")) == 0) {
						String checkininputXml = "<?xml version=\"1.0\"?><NGOCheckinCheckoutExt_Input><Option>NGOCheckinCheckoutExt</Option><CabinetName>"
								+ pp.getCabinateName() + "</CabinetName><UserDBId>" + sessionId
								+ "</UserDBId><CurrentDateTime></CurrentDateTime><LimitCount>1000</LimitCount><CheckInOutFlag>N</CheckInOutFlag><SupAnnotVersion>N</SupAnnotVersion><Documents><Document><DocumentIndex>"
								+ dbData.get(0) + "</DocumentIndex><ISIndex>" + isIndexNew
								+ "</ISIndex><VersionComment>" + comment
								+ "</VersionComment><DocumentType>N</DocumentType><NoOfPages>" + 1
								+ "</NoOfPages><DocumentSize>" + f.length() + "</DocumentSize><CreatedByAppName>" + ext
								+ "</CreatedByAppName></Document></Documents></NGOCheckinCheckoutExt_Input>";
						response.setXmlString(dApi.callBroker(checkininputXml));
						LOGGER.info("Checkout XML :" + response.strXML);
						if (Integer.parseInt(response.getVal("Status")) == 0) {
							String propertyChange = "<?xml version=\"1.0\"?><NGOChangeDocumentProperty_Input><Option>NGOChangeDocumentProperty</Option><CabinetName>"
									+ pp.getCabinateName() + "</CabinetName><UserDBId>" + sessionId
									+ "</UserDBId><Document><DocumentIndex>" + dbData.get(0)
									+ "</DocumentIndex><NoOfPages>1</NoOfPages><DocumentName>"
									+ response.getVal("DocumentName") + "</DocumentName><AccessDateTime>"
									+ response.getVal("AccessDateTime") + "</AccessDateTime><ISIndex>" + isIndexNew
									+ "</ISIndex><VersionComment>Revised</VersionComment><DocumentType>" + docType
									+ "</DocumentType><DocumentSize>" + f.length()
									+ "</DocumentSize><DataDefinition></DataDefinition><RetainAnnotation>N</RetainAnnotation></Document></NGOChangeDocumentProperty_Input>";
							response.setXmlString(dApi.callBroker(propertyChange));
							LOGGER.debug("Property Change : " + response);
							vr = new VersionResponse();
							vr.setDocId(Integer.parseInt(response.getVal("DocumentIndex")));
							;
							vr.setStatus((response.getVal("Status")));
							vr.setVerNo(Float.parseFloat(response.getVal("DocumentVersionNo")));
							String indexParse = response.getVal("ISIndex");
							indexParse = indexParse.substring(0, indexParse.indexOf("#"));
							vr.setDocumentIndex(Integer.parseInt(indexParse));
						}
					} else {
						LOGGER.info("Incomplete Version Upload Call");
						vr.setDocId(0);
						vr.setVerNo(0);
						vr.setDocumentIndex(0);
						vr.setStatus(response.getVal("Error"));
					}
				} catch (JPISException e) {
					LOGGER.warn(e);
				}
			} catch (IOException e) {
				LOGGER.warn(e);
			}
		}
		return vr;
	}

	public static String testPdf(String filename) {
		int num = 0;
		List img = null;
		try {
			PDDocument doc = PDDocument.load(new File(filename));
			num = doc.getNumberOfPages();
			img = doc.getDocument().getObjects();
		} catch (IOException e) {
			LOGGER.warn(e);
		}

		if (num == img.size()) {
			return "I";
		} else {
			return "N";
		}
	}

	public ArrayList getIsIndex(int docId) {
		al.clear();
		try {
			Connection conn = dbconn.getConnection();
			String query = "select d.documentIndex,d.Name,d.ImageIndex,d.VolumeId,e.ParentFolderIndex from pdbdocument d,PDBDocumentContent e\r\n"
					+ " where e.DocumentIndex=d.DocumentIndex and e.DocumentIndex=?";
			PreparedStatement ps = conn.prepareStatement(query, ResultSet.TYPE_SCROLL_INSENSITIVE,
					ResultSet.CONCUR_READ_ONLY);

			ps.setInt(1, docId);
			ResultSet rs = ps.executeQuery();
			if (rs.next() == false) {
				LOGGER.info("Empty ResultSet !");
				al.add(0);
			} else {
				rs.beforeFirst();
				while (rs.next()) {
					al.add(rs.getInt(1));
					al.add(rs.getString(2));
					al.add(rs.getInt(3));
					al.add(rs.getInt(4));
					al.add(rs.getInt(5));
				}
			}
		} catch (SQLException e) {
			LOGGER.warn(e);
		}
		LOGGER.debug("Data from Table :" + al);
		return al;
	}
}
