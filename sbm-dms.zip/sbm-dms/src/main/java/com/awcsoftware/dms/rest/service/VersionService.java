/**
 * 
 */

package com.awcsoftware.dms.rest.service;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.awcsoftware.dms.api.DmsApi;
import com.awcsoftware.dms.api.DocumentVersioning;
import com.awcsoftware.dms.dto.VersionRequest;
import com.awcsoftware.dms.dto.VersionResponse;

/**
 * @author Shuaib
 *
 */
@Service
public class VersionService {
	final static Logger LOGGER = Logger.getLogger(VersionService.class);

	@Autowired
	private DmsApi api;

	@Autowired
	private DocumentVersioning dv;

	public VersionResponse versionService(String sessionId, VersionRequest vr) {
		LOGGER.info("Entered versionService method");
		// vr.setDocId(Integer.parseInt(vdpb.getDocumentId()));
		if (vr.getComment() == "" || vr.getComment() == null) {
			LOGGER.debug("Entered If");
			VersionResponse res = new VersionResponse("0", 0, 0.0f, 0, "Please put some comment");
			return res;
		} else {
			LOGGER.debug("Entered else");
			VersionResponse res = dv.checkin(vr, sessionId);
			api.disconnect(sessionId);
			return res;
		}
	}
}
