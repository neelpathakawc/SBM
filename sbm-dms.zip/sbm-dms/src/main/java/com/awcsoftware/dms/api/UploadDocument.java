/**
 * 
 */
package com.awcsoftware.dms.api;

import java.io.File;
import java.io.IOException;
import java.text.DateFormatSymbols;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.awcsoftware.base64.EncryptionOppo;
import com.awcsoftware.bytes.BytesConvertion;
import com.awcsoftware.dms.dto.BaseData;
import com.awcsoftware.dms.dto.Document;

import com.awcsoftware.dms.dto.UploadResponse;
import com.awcsoftware.dms.dto.VersionRequest;
import com.awcsoftware.dms.dto.VersionResponse;
import com.awcsoftware.dms.rest.service.SbmDBOperations;
import com.awcsoftware.spring.data.jpa.ConnectSbmDB;
import com.newgen.dmsapi.DMSXmlResponse;

import ISPack.CPISDocumentTxn;
import ISPack.ISUtil.JPDBRecoverDocData;
import ISPack.ISUtil.JPISException;
import ISPack.ISUtil.JPISIsIndex;

/**
 * @author Shuaib
 *
 */

@Service
public class UploadDocument {
	final static Logger LOGGER = Logger.getLogger(UploadDocument.class);
	private BytesConvertion bc;
	private JPDBRecoverDocData docDBData;
	private JPISIsIndex newIsIndex;
	private DMSXmlResponse resp;
	private int docIndex;
	private String isIndex = null;
	private String fileLocation = "C:\\Newgen\\Server\\LocalRepository\\";
	private DmsApi api;
	private EncryptionOppo eo;
	private DmsProperties pp;
	@Autowired
	private SbmDBOperations dbOps;
	private ConnectSbmDB cob;
	private Object docsType;
	@Autowired
	private DocumentVersioning dv;

	@Autowired
	public UploadDocument(JPDBRecoverDocData docDBData, JPISIsIndex newIsIndex, DmsApi api, DMSXmlResponse resp,
			DmsProperties pp, BytesConvertion bc, EncryptionOppo eo, ConnectSbmDB cob) {
		super();
		LOGGER.info("UploadDocument Parameterized Constructor called");

		// this.dbOps = dbOps;
		this.docDBData = docDBData;
		this.newIsIndex = newIsIndex;
		this.api = api;
		this.resp = resp;
		this.pp = pp;
		this.bc = bc;
		this.eo = eo;
		this.cob = cob;
		LOGGER.debug("this.docDBData= " + this.docDBData + "this.newIsIndex= " + this.newIsIndex + "this.api= "
				+ this.api + "this.resp= " + this.resp + "this.pp= " + this.pp + "this.bc= " + this.bc + "this.eo= "
				+ this.eo + "this.cob= " + this.cob);
	}
	

	private static String getFileExtension(File file) {

		String fileName = file.getName();
		if (fileName.lastIndexOf(".") != -1 && fileName.lastIndexOf(".") != 0) {
			return fileName.substring(fileName.lastIndexOf(".") + 1);
		} else {
			return "";
		}
	}

	public String getDocType(String ext) {
		String docType = "";
		if (ext.equalsIgnoreCase("jpg") || ext.equalsIgnoreCase("JPEG") || ext.equalsIgnoreCase("png")
				|| ext.equalsIgnoreCase("tiff") || ext.equalsIgnoreCase("bmp") || ext.equalsIgnoreCase("png")) {
			LOGGER.info("Doctype is Image");
			docType = "I";
		} else if (ext.equalsIgnoreCase("mp4") || ext.equalsIgnoreCase("vob") || ext.equalsIgnoreCase("mkv")
				|| ext.equalsIgnoreCase("webm") || ext.equalsIgnoreCase("avi")) {
			LOGGER.info("Doctype is Video");
			docType = "V";
		} else if (ext.equalsIgnoreCase("pdf")) {
			docType = "I";
		} else {
			LOGGER.info("Doctype is Others");
			docType = "N";
		}
		return docType;
	}

	public UploadResponse upload(BaseData bd, String sessionId) {
		LOGGER.info("Inside upload()" + "\tdd= " + bd + "\tsessionId= " + sessionId);
		UploadResponse ur = new UploadResponse();
		File tempFile = null;
		String locationData = null;
		Document dd = null;
		LOGGER.debug("cob= " + cob + "\tresp= " + resp + "\tdmsapi= " + api + "\tdbOps= " + dbOps);
//		dbOps = new SbmDBOperations(cob, resp, api);
		boolean testDocType = true;
		if (dbOps.validateSessionId(sessionId)) {
			if (bd instanceof Document) {
				dd = (Document) bd;
				locationData = dd.getCifId();
			}
			int leadfolder = 0;
			// Passing cifId
			int folderIndex = dbOps.validateCreateFolder(locationData, bd, sessionId);
			if (folderIndex > 0) {
				leadfolder = folderIndex;
			}
			LOGGER.debug("folderIndex= " + folderIndex);
			// int folderIndex = 55;
			if (folderIndex == 0) {
				LOGGER.info("DMS Root folder= "+pp.getDmsRootFolder());
				int cifIndex = dbOps.createFolderByName(pp.getDmsRootFolder(), dd.getCifId(), sessionId);
				LOGGER.debug("CIF Folder created with Index= " + cifIndex);
				leadfolder = dbOps.validateCreateFolder(locationData, bd, sessionId);
			} else if (folderIndex == -1) {
				ur.setDocId(0);
				ur.setImageIndex(0);
				ur.setStatus("Please contact Admin, Location Root Folder is more than one in Omnidocs");
				return ur;
			}
			if (leadfolder > 0) {
				try {
					// int folderIndex = dbOps.validateCreateFolder(locationData,dd,sessionId);
					LOGGER.debug("Tracking Folder Index :" + leadfolder);
					// String dummyFileName=dd.getLeadId()+" "+dd.getDocumentType()+"
					// "+dd.getDocument()+" "+dd.getApplicant();
					// String orignalName=dd.getDocN().substring(dd.getDocN().lastIndexOf("."));
					bd.setDocN(bd.getDocType() + "_" + bd.getDocN());
					LOGGER.info("after setDocN" + "\tDocN= " + bd.getDocN());
					LOGGER.debug("First writing to local drive at fileLocation= " + fileLocation);
					LOGGER.debug("dd.getBinData()" + bd.getBinData());
					/*
					 * for (byte b : dd.getBinData()) { System.out.print(" " + b); }
					 */
					tempFile = bc.writeByteArraysToFile(fileLocation + bd.getDocN(), eo.decodeData(bd.getBinData()));
					LOGGER.debug("eo.decodeData(dd.getBinData())= " + eo.decodeData(bd.getBinData()));
					LOGGER.debug("tempFile=" + tempFile);
					String docType = getDocType(getFileExtension(tempFile));
					LOGGER.debug("docType= " + docType);
					String fileName = null;
					fileName = bd.getDocN().substring(0,
							bd.getDocN().length() - (getFileExtension(tempFile).length() + 1));

					// select query to find all list of documents name presents in leadFolder
					// boolean docExist=dbOps.isDocumentExist(leadfolder);
					String getDocumentListXML = "><NGOGetDocumentListExt_Input><Option>NGOGetDocumentListExt</Option><CabinetName>"+pp.getCabinateName()+"</CabinetName>"
							+ "<UserDBId>" + sessionId + "</UserDBId><CurrentDateTime></CurrentDateTime><FolderIndex>"
							+ leadfolder + "</FolderIndex><DocumentIndex></DocumentIndex>"
							+ "<PreviousIndex></PreviousIndex><LastSortField></LastSortField><StartPos></StartPos><NoOfRecordsToFetch></NoOfRecordsToFetch>"
							+ "<OrderBy></OrderBy><SortOrder></SortOrder><DataAlsoFlag></DataAlsoFlag><AnnotationFlag></AnnotationFlag><LinkDocFlag>"
							+ "</LinkDocFlag><ReferenceFlag></ReferenceFlag><PreviousRefIndex></PreviousRefIndex><LastRefField></LastRefField><RefOrderBy>"
							+ "</RefOrderBy><RefSortOrder></RefSortOrder><NoOfReferenceToFetch></NoOfReferenceToFetch><DocumentType>"
							+ "</DocumentType><RecursiveFlag></RecursiveFlag><ThumbnailAlsoFlag></ThumbnailAlsoFlag></NGOGetDocumentListExt_Input>";

					System.out.println(
							"*******************************************************************************************************");
					String documentListOutputXml = api.callBroker(getDocumentListXML);
					LOGGER.debug("documentListOutputXml=\n" + documentListOutputXml);

					boolean isdocumentExist = false;
					int versionDocId = 0;
					resp.setXmlString(documentListOutputXml);

					LOGGER.debug("NGOGetDocumentListExt_Input resp= " + resp);
					LOGGER.debug("resp.getVal(\"NoOfRecordsFetched\")= " + resp.getVal("NoOfRecordsFetched"));
					if (!resp.getVal("Status").equalsIgnoreCase("0")) {
						LOGGER.info("Error in DMS Call broker for <NGOGetDocumentListExt_Input>");
						LOGGER.debug("Incomplete NGOGetDocumentListExt_Input Upload Call");
						ur.setDocId(0);
						ur.setImageIndex(0);
						ur.setStatus(resp.getVal("Error"));
					} else if (!resp.getVal("NoOfRecordsFetched").equalsIgnoreCase("0")) {
						System.out.println(
								"@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
						LOGGER.debug(
								"Completed Document NGOGetDocumentListExt_Input Call to DMS \nDocument List Found in this Folder!");
						String[] documentTags = documentListOutputXml.split("<Document>");
						LOGGER.debug(documentTags);
						for (String documentTag : documentTags) {
							resp.setXmlString(documentTag);
							LOGGER.debug(resp);
							String documentName = resp.getVal("DocumentName");
							LOGGER.debug("DocumentName= " + documentName);
							if (documentName.equals(fileName)) {
								versionDocId=Integer.parseInt(resp.getVal("DocumentIndex"));
								LOGGER.debug("versionDocId= "+versionDocId);
								isdocumentExist = true;
								break;
							}
						}

					} else {
						LOGGER.debug(
								"Completed Document NGOGetDocumentListExt_Input Call to DMS \n No Document List Found in this Folder!");
					}
					if(isdocumentExist) {
						VersionRequest vr=new VersionRequest(versionDocId, getFileExtension(tempFile), "This version is internally created at Upload document call", dd.getBinData());
						LOGGER.debug("Doocument Versioning checkin called");
						VersionResponse res = dv.checkin(vr, sessionId);
						ur.setDocId(res.getDocId());
						ur.setDocumentVersion(res.getVerNo());
						ur.setImageIndex(res.getDocumentIndex());
						ur.setStatus(res.getStatus());
						LOGGER.debug("Returning ur="+ur);
						return ur;
					}
					LOGGER.debug("fileName= " + fileName);
					LOGGER.debug("After fileName");
					int pageNum = 1;

					if (getFileExtension(tempFile).equals("pdf")) {
						if (getFileExtension(tempFile).equals("pdf")) {
							PDDocument doc = PDDocument.load(tempFile);
							pageNum = doc.getNumberOfPages();
							doc.close();
						}

					}
					LOGGER.debug("Pdf if completed");

					// xml dummy which wil be further modified to Add Document into Document Cabinet
					// i.e. sbm
					// xml dummy of Step-2 input to callBroker same as result of getAddDocumentXml()
					String xmlData = "<?xml version=\"1.0\"?><NGOAddDocument_Input><Option>NGOAddDocument</Option><CabinetName>"
							+ pp.getCabinateName() + "</CabinetName><UserDBId>" + sessionId
							+ "</UserDBId><GroupIndex></GroupIndex><Document><ParentFolderIndex>" + leadfolder
							+ "</ParentFolderIndex><NoOfPages>" + pageNum
							+ "</NoOfPages><AccessType>S</AccessType><DocumentName>" + fileName
							+ "</DocumentName><CreationDateTime></CreationDateTime><ExpiryDateTime></ExpiryDateTime><VersionFlag>N</VersionFlag><DocumentType>"
							+ docType + "</DocumentType><DocumentSize>" + tempFile.length()
							+ "</DocumentSize><CreatedByApp></CreatedByApp><CreatedByAppName>"
							+ getFileExtension(tempFile)
							+ "</CreatedByAppName><ISIndex></ISIndex><FTSDocumentIndex>0</FTSDocumentIndex><ODMADocumentIndex></ODMADocumentIndex><Comment></Comment><Author></Author><OwnerIndex>1</OwnerIndex><EnableLog>Y</EnableLog><FTSFlag>PP</FTSFlag>"
							+ "<DataDefinition><DataDefIndex>3</DataDefIndex><Field><IndexId>9</IndexId><IndexType>S</IndexType><IndexValue>";
					if (bd instanceof Document) {
						LOGGER.info("bd instanceof DocumentData");
						xmlData += dd.getCifId()
								+ "</IndexValue></Field><Field><IndexId>10</IndexId><IndexType>S</IndexType><IndexValue>"
								+ dd.getAccountNumber()
								+ "</IndexValue></Field><Field><IndexId>11</IndexId><IndexType>S</IndexType><IndexValue>"
								+ dd.getAccountType()
								+ "</IndexValue></Field><Field><IndexId>12</IndexId><IndexType>S</IndexType><IndexValue>"
								+ dd.getDocType()
								+ "</IndexValue></Field><Field><IndexId>13</IndexId><IndexType>S</IndexType><IndexValue>"
								+ dd.getDocN() + "</IndexValue></Field><Field>\r\n"
								+ "<IndexId>14</IndexId><IndexType>S</IndexType><IndexValue>" + dd.getApplicantName()
								+ "</IndexValue></Field>";
					}
					xmlData += "</Fields></DataDefinition><NameLength>255</NameLength></Document></NGOAddDocument_Input>";

					LOGGER.debug("xmlData Input= " + xmlData);
					String outputXml = null;

					// jstsport should be dynamic

					LOGGER.debug("docDBData= " + docDBData + " newIsIndex= " + newIsIndex);

					// Step-1 of 2 - Add document into the Image Server. (Physical storage of
					// document)
					CPISDocumentTxn.AddDocument_MT(null, pp.getServerIP(), Short.parseShort("3333"),
							pp.getCabinateName(), Short.parseShort("1"), fileLocation + bd.getDocN(), docDBData, "1",
							newIsIndex);
					docIndex = newIsIndex.m_nDocIndex;
					isIndex = newIsIndex.m_nDocIndex + "#" + newIsIndex.m_sVolumeId;
					LOGGER.info("DocIndex :" + docIndex + " /isIndex :" + isIndex);
					String frontData = xmlData.substring(0, xmlData.indexOf("<ISIndex>") + 9);
					String endData = xmlData.substring(xmlData.indexOf("</ISIndex>"), xmlData.length());
					xmlData = frontData + isIndex + endData;
					LOGGER.info("xmlData input to DMSCallBroker.execute() = " + xmlData);
					// Step-2- Adding the Storage Information and Property into Document Cabinet.
					outputXml = api.callBroker(xmlData);
					resp.setXmlString(outputXml);

					LOGGER.debug("Upload Call " + resp);

					if (resp.getVal("Status").equalsIgnoreCase("0")) {
						LOGGER.debug("Completed Document Upload Call");
						String indexParse = resp.getVal("ISIndex");
						indexParse = indexParse.substring(0, indexParse.indexOf("#"));
						ur.setDocId(Integer.parseInt(resp.getVal("DocumentIndex")));
						ur.setStatus(resp.getVal("Status"));
						ur.setImageIndex(Integer.parseInt(indexParse));
						ur.setDocumentVersion(1.0f);
					} else {
						LOGGER.debug("Incomplete Document Upload Call");
						ur.setDocId(0);
						ur.setImageIndex(0);
						ur.setStatus(resp.getVal("Error"));

					}
					LOGGER.debug("Call Broker to add document :" + outputXml);

				} catch (IOException | JPISException e) {
					LOGGER.error(e);
				} finally {
					// dbOps = null;
					LOGGER.debug("Before Delete Operation : ");
					LOGGER.debug("File Delete Operation : " + tempFile.delete());
					LOGGER.debug("After Delete Operation : ");
					tempFile = null;
				}
			}
			return ur;
		} else {
			ur.setDocId(0);
			ur.setImageIndex(0);
			ur.setStatus("Invalid Session Id");
			LOGGER.debug("UploadResponse= " + ur);
			return ur;
		}

	}


	static String getMonthForInt(int num) {
		String month = "wrong";
		DateFormatSymbols dfs = new DateFormatSymbols();
		String[] months = dfs.getMonths();
		if (num >= 0 && num <= 11) {
			month = months[num];
		}
		LOGGER.debug("Month :" + month);
		return month;
	}

	/*
	 * public static void main(String[] args) {
	 * LOGGER.info("Inside Main of Upload Document"); BytesConvertion bc = new
	 * BytesConvertion(); EncryptionOppo eo = new EncryptionOppo();
	 * LOGGER.info("BytesConvertion, EncryptionOppo Object Created"); Byte[] bv =
	 * eo.encodeData(bc.convertToByteData("D:\\General\\dummy.pdf"));
	 * LOGGER.info("encodeData() called bv.toString() is= " + bv.toString());
	 * System.out.println("Bytes Data size= " + bv.length); // for (byte b : bv) {
	 * // System.out.print(b + ", "); // } }
	 */

}