package com.awcsoftware.dms.dto;

public class DownloadMetaData {
	private int imgIndex;
	private String cifId;
	private String accountNumber;
	private String accountType;
	private String docType;
	private String docN;
	private String applicantName;

	public DownloadMetaData(String cifId, String accountNumber, String accountType, String docType, String docN,
			String applicantName) {
		super();
		this.cifId = cifId;
		this.accountNumber = accountNumber;
		this.accountType = accountType;
		this.docType = docType;
		this.docN = docN;
		this.applicantName = applicantName;
	}

	public int getImgIndex() {
		return imgIndex;
	}


	public void setImgIndex(int imgIndex) {
		this.imgIndex = imgIndex;
	}


	public String getCifId() {
		return cifId;
	}

	public void setCifId(String cifId) {
		this.cifId = cifId;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public String getDocType() {
		return docType;
	}

	public void setDocType(String docType) {
		this.docType = docType;
	}

	public String getDocN() {
		return docN;
	}

	public void setDocN(String docN) {
		this.docN = docN;
	}

	public String getApplicantName() {
		return applicantName;
	}

	public void setApplicantName(String applicantName) {
		this.applicantName = applicantName;
	}

	@Override
	public String toString() {
		return "DownloadMetaData [cifId=" + cifId + ", accountNumber=" + accountNumber + ", accountType=" + accountType
				+ ", docType=" + docType + ", docN=" + docN + ", applicantName=" + applicantName + "]";
	}
	
	
}
