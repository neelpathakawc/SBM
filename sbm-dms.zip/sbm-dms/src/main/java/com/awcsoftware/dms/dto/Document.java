package com.awcsoftware.dms.dto;

import java.util.Arrays;

import javax.validation.constraints.NotEmpty;

public class Document extends BaseData {
	@NotEmpty(message = "Please provide CIF Id!")
	private String cifId;

	@NotEmpty(message = "Please provide A/c Number!")
	private String accountNumber;

	private String accountType;

	@NotEmpty(message = "Please provide Applicant Name!")
	private String applicantName;

	public Document(String docN, String docType, byte[] binData, String cifId, String accountNumber, String accountType,
			String applicantName) {
		super(docN, docType, binData);
		this.cifId = cifId;
		this.accountNumber = accountNumber;
		this.accountType = accountType;
		this.applicantName = applicantName;
	}

	public String getCifId() {
		return cifId;
	}

	public void setCifId(String cifId) {
		this.cifId = cifId;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public String getApplicantName() {
		return applicantName;
	}

	public void setApplicantName(String applicantName) {
		this.applicantName = applicantName;
	}

	@Override
	public String toString() {
		return "Document [cifId=" + cifId + ", accountNumber=" + accountNumber + ", accountType=" + accountType
				+ ", applicantName=" + applicantName + ", binData=" + binData + "]";
	}
}