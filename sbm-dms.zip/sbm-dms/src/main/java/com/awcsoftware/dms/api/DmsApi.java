package com.awcsoftware.dms.api;

import java.io.IOException;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.awcsoftware.dms.dto.UserData;
import com.awcsoftware.exception.SbmException;
import com.newgen.dmsapi.DMSCallBroker;
import com.newgen.dmsapi.DMSInputXml;
import com.newgen.dmsapi.DMSXmlResponse;

@Service
//@Profile(value = "prod")
//@Lazy
public class DmsApi {
	static Logger LOGGER = Logger.getLogger(DmsApi.class);
	private DMSInputXml inputXml;
	private DMSXmlResponse xmlResponse;
	private DmsProperties properties;

	@Autowired
//	@Qualifier("dmsProperties")
	public DmsApi(DMSInputXml inputXml, DMSXmlResponse xmlResponse, DmsProperties properties) {
		super();
		this.inputXml = inputXml;
		this.xmlResponse = xmlResponse;
		this.properties = properties;
	}

	public String connect(UserData ud) {
		LOGGER.info("Entered connect()");
		String input = inputXml.getConnectCabinetXml(properties.getCabinateName(), ud.getUsername(),
				ud.getUserpassword(), "", "Y", "0", "S", "");
		LOGGER.debug("inputXml=" + input);
		String output = callBroker(input);
		LOGGER.debug("outputXml" + output);
		return getSessionId(output);
	}

	public String disconnect(String sessionId) {
		LOGGER.info("Entered disconncet()");
		return callBroker(inputXml.getDisconnectCabinetXml(properties.getCabinateName(), sessionId));
	}

	public String callBroker(String input) {
		LOGGER.info("Entered callBroker()");
		String outputXml = null;
		try {
			outputXml = DMSCallBroker.execute(input, properties.getServerIP(), 3333, 0);
			LOGGER.debug("outputXml=" + outputXml);
		} catch (IOException e) {
			LOGGER.error("Error in DMS callBroker call " + e);
			e.printStackTrace();
			throw new SbmException( " Connection Timeout: Could not able to connect to DMS Server");
		}
		return outputXml;
	}

	public String getSessionId(String setXml) {
		LOGGER.info("Entered getSessionId()");
		String output;
		xmlResponse.setXmlString(setXml);
		if (xmlResponse.getVal("Status").equalsIgnoreCase("0")) {
			output = xmlResponse.getVal("UserDBId");
		} else {
			output = xmlResponse.getVal("Error");
			LOGGER.debug("getSessionId()" + output);
			throw new SbmException("Some error in omnidocs with the running jboss server. ");
		}
		LOGGER.debug("getSessionId()" + output);

		return output;
	}

	public String createFolder(int parentFolderIndex, String folderName, String sessionId) {
		LOGGER.info("Entered createFolder()");

		String input = null;
		String output = null;
		input = inputXml.getAddFolderXml(properties.getCabinateName(), sessionId, String.valueOf(parentFolderIndex),
				folderName, "", "", "1", "", "", "", "N", "", "", "", "", "", "", "Y", "", "255", "0", "0", "", "");
		output = callBroker(input);
//		LOGGER.info("inputXml to callBroker= " + input);
//		LOGGER.info("output xml= " + output);
		return output;
	}

}
