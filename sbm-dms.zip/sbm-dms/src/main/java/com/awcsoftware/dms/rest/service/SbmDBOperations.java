package com.awcsoftware.dms.rest.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.jdbc.JdbcTemplateAutoConfiguration;
import org.springframework.stereotype.Service;

import com.awcsoftware.dms.api.DmsApi;
import com.awcsoftware.dms.dto.Document;
import com.awcsoftware.dms.dto.VersionContent;
import com.awcsoftware.exception.SbmException;
import com.awcsoftware.spring.data.jpa.ConnectSbmDB;
import com.newgen.dmsapi.DMSXmlResponse;

@Service
public class SbmDBOperations {
	final static Logger LOGGER = Logger.getLogger(SbmDBOperations.class);
	private DMSXmlResponse xmlResponse;
	private DmsApi api;
	private ConnectSbmDB dbCon;
	private String versionContentQuery = "select DocumentIndex,VersionNumber,VersionComment,ImageIndex from PDBDocument where DocumentIndex=?";
	private String rootFolderQuery = "select Name,FolderIndex from PDBFolder where Name=?";
	private String cfRootFolderQuery = "select Name,FolderIndex from PDBFolder where Name=? And ParentFolderIndex=(select FolderIndex from PDBFolder where Name=?);";
	private String cfSubRootFolderQuery = "select Name,FolderIndex from PDBFolder where Name=? And ParentFolderIndex=?;";

	private String generalFolderIdQuery = "select name,ParentFolderIndex,FolderIndex from PDBFolder where ParentFolderIndex=?";
	private String sessionIdQuery = "select * from PDBConnection where RandomNumber=?";
	private String parentFolderQuery = "select Name from PDBFolder where FolderIndex=(select ParentFolderIndex from PDBFolder where FolderIndex=?)";
//	private String documentListQuery = "select * from PDBFolder where Folder=?";

	private int flag = 0;
	@Autowired
	VersionContent vc;
//	@Autowired
//	private ConnectSbmDB cob;

	@Autowired
	public SbmDBOperations(ConnectSbmDB dbCon, DMSXmlResponse xmlResponse, DmsApi cb) {
		LOGGER.info("SbmDBOperations(DataSource dbCon, DMSXmlResponse xmlResponse, DmsApi cb) Constructor called...");
		this.dbCon = dbCon;
		this.xmlResponse = xmlResponse;
		this.api = cb;
		LOGGER.info(
				"this.dbCon= " + this.dbCon + "\tthis.xmlResponse= " + this.xmlResponse + "\tthis.api= " + this.api);
	}

	public VersionContent getVersionData(int docId) {
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			conn = dbCon.getConnection();
			LOGGER.info("conn= " + conn);
			ps = conn.prepareStatement(versionContentQuery);
			ps.setInt(1, docId);
			rs = ps.executeQuery();
			while (rs.next()) {
				vc.setDocumentId(rs.getInt(1));
				vc.setVersion(rs.getFloat(2));
				vc.setVersionComment(rs.getString(3));
				vc.setImageIndex(rs.getInt(4));
			}
		} catch (SQLException e) {
			LOGGER.error("Error occured= " + e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (ps != null)
					ps.close();
				if (conn != null)
					conn.close();
			} catch (SQLException e) {
				LOGGER.error("Error occured= " + e);
			}
		}
		return vc;
	}

	int parentFolderIndex = 0;

	public synchronized <T> int validateCreateFolder(String locationData, T dd, String sesisonId) {
		//location data is cif at 1st call
		LOGGER.info("Entered updated validateCreateFolder method for creating subFolder");
		int root = rootFolder(locationData, dd, sesisonId);
		LOGGER.info("dd " + dd + "\tlocationData= " + locationData + "\troot= " + root);
		return root;

	}

	public <T> int validateCreateSubFolder(String locationData, int parentIndex, T dd, String sesisonId) {
		//location data is AccountNumber at 1st call & ParentIndex is Cif Index
		//location data is docType at 2nd call & ParentIndex is Account Number Index
		LOGGER.info("Entered updated validateCreateSubFolder method for creating subFolder");
		LOGGER.debug("sub Folder (i.e AccountNumber at 1st call or docType at 2nd call) locationData= " + locationData);
		int root = rootSubFolder(locationData, parentIndex, dd, sesisonId);
		LOGGER.debug("root= " + root);
		return root;
	}

	public <T> int rootSubFolder(String locationData, int parentIndex, T dd, String sessionId) {
		//location data is AccountNumber at 1st call & ParentIndex is cif Index
		//location data is docType at 2nd call & ParentIndex is Account Number Index

		// this method returns AccountNumber\docType Folder Index
		 LOGGER.info("Entered rootSubFolder method ");
		LOGGER.debug("locationData(i.e AccountNumber at 1st call or docType at 2nd call)= " + locationData + "parent(i.e Cif Index or acNumber index) = " + parentIndex);
		int data = 0;
		flag = 0;
		int locationIndex = 0;
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			conn = dbCon.getConnection();
			// cfSubRootFolderQuery to test- Is AccountNumber already exits?
			ps = conn.prepareStatement(cfSubRootFolderQuery);
			ps.setString(1, locationData);
			ps.setInt(2, parentIndex);
			rs = ps.executeQuery();

			while (rs.next()) {
				if (rs.getString(1).equals(locationData)) {
					flag++;
					locationIndex = rs.getInt(2);
				}
			}
			LOGGER.debug("locationIndex= " + locationIndex);
			if (flag == 1) {
				data = locationIndex;
			} else if (flag > 1) {
				data = -1;
			} else if (flag == 0) {
				data = 0;
			}
		} catch (SQLException e) {
			LOGGER.error(e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (ps != null)
					ps.close();
				if (conn != null)
					conn.close();
			} catch (SQLException e) {
				LOGGER.error(e);
			}
		}
		LOGGER.info("data= " + data);
		return data;
	}

	public <T> int rootFolder(String locationData, T dd, String sessionId) {
		//location data is cif at 1st call
		//returns docType Folder Index as root Folder
		LOGGER.debug("Entered rootFolder method "+" locationData= " + locationData);
		int data = 0;
		flag = 0;
		int locationIndex = 0;
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			conn = dbCon.getConnection();
			ps = conn.prepareStatement(rootFolderQuery);
			ps.setString(1, locationData);
			rs = ps.executeQuery();

			while (rs.next()) {
				if (rs.getString(1).equals(locationData)) {
					flag++;
					locationIndex = rs.getInt(2);
				}
			}
			LOGGER.debug("locationIndex= " + locationIndex);

			// if single location data(i.e cif at 1st call) folder exist in dms consider it as parent folder index
			if (flag == 1) {
				parentFolderIndex = locationIndex;
				LOGGER.debug("parentFolderIndex= " + parentFolderIndex);
				T d = null;
				LOGGER.debug("Entered if, Flag =1");
					Document dc;
					if (dd instanceof Document) {
						dc = (Document) dd;
						d = (T) dc;
						int acNumberIndex = 0;
						int docTypeIndex=0;
						//call validateCreateSubFolder to create\validate AccountNumber folder
						//return AccountNumber Index if already exist other wise -1 or 0
						data = validateCreateSubFolder(dc.getAccountNumber(), parentFolderIndex, d, sessionId);
						LOGGER.debug("validateCreateSubFolder method returned data= " + data);
						acNumberIndex=data;
						if (data == -1) {
							return data;
						}else if (data == 0) {
							LOGGER.info("Entered if(data==0" + "\tparentFolderIndex= " + parentFolderIndex);
							acNumberIndex=createFolderByName(parentFolderIndex, dc.getAccountNumber(), sessionId);
							LOGGER.debug("AcNumberIndex= " + acNumberIndex);
						}
						data=validateCreateSubFolder(dc.getDocType(), acNumberIndex, dd, sessionId);
						docTypeIndex=data;
						if (data == -1) {
							return data;
						}else if (data == 0) {
							LOGGER.info("Entered if(data==0" + "\tparentFolderIndex= " + parentFolderIndex);
							docTypeIndex=createFolderByName(acNumberIndex, dc.getDocType(), sessionId);
							LOGGER.debug("docTypeIndex= " + docTypeIndex);
						}
						parentFolderIndex = docTypeIndex;
					} 
//					d = dd;
					data = leadIdFolder(d, parentFolderIndex, sessionId);
			} else if (flag > 1) {
				data = -1;
			} else if (flag == 0) {
				data = 0;
			}
		} catch (SQLException e) {
			LOGGER.error("Error occured" + e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (ps != null)
					ps.close();
				if (conn != null)
					conn.close();
			} catch (SQLException e) {
				LOGGER.error(e);
			}
		}
		LOGGER.debug("data= " + data);
		return data;
	}

	public <T> int leadIdFolder(T dd, int parentFolderIndex, String sessionId) {
		//return docType Folder index
		LOGGER.info("Entered leadIdFolder method");
		int data = 0;
		flag = 0;
		Connection conn = null;
		PreparedStatement ps = null;
		PreparedStatement ps2 = null;
		ResultSet rs = null;
		ResultSet rs2 = null;
		int folderIndex = 0;
		LOGGER.debug("parentFolderIndex= " + parentFolderIndex);
		try {
			conn = dbCon.getConnection();
			LOGGER.debug("conn= " + conn);
			Document d = (Document) dd;
			ps = conn.prepareStatement(generalFolderIdQuery);
			LOGGER.debug("Lead Id :" + d.getApplicantName());
			ps.setInt(1, parentFolderIndex);
			rs = ps.executeQuery();
			while (rs.next()) {
				if (rs.getString(1).equals(d.getApplicantName())) {
					flag++;
					// Addition on June 13
					folderIndex = rs.getInt(3);
					break;
				}
			}
			if(flag== -1) {
				return flag;
			}
			else if (flag == 0) {
				data=createFolderByName(parentFolderIndex, d.getApplicantName(), sessionId);
				LOGGER.debug("Lead Folder " + d.getApplicantName()+" created with index= "+data);

			}
			else{
				data = folderIndex;
			}

		} catch (SQLException e) {
			LOGGER.error(e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (ps != null)
					ps.close();
				if (conn != null)
					conn.close();
			} catch (SQLException e) {
				LOGGER.error(e);
			}
		}
		return data;
	}

	public boolean validateSessionId(String sessionId) {
		LOGGER.info("Entered validateSessionId() sessionId" + sessionId);
		Connection conn = null;
		boolean flag = false;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			LOGGER.info("Entered try");
			LOGGER.info("dbConn= " + dbCon);
			conn = dbCon.getConnection();
			LOGGER.info("conn= " + conn);
			ps = conn.prepareCall(sessionIdQuery);
			LOGGER.info("sessionId= " + sessionId);
			ps.setInt(1, Integer.parseInt(sessionId));
			rs = ps.executeQuery();
			if (rs.next()) {
				LOGGER.debug("Entered if i.e. ResultSet is not null");
				flag = true;
				rs.close();
			}
			if (flag != true) {
				throw new SbmException("Invalid Session Id");
			}

			/*
			 * while(rs.next()) { System.out.println("From While"); flag=true; }
			 */
			LOGGER.info("After");
		} catch (SQLException e) {
			LOGGER.error(e);
			throw new SbmException("Error occured after getting connection & during database operartions!");

		} finally {
			try {
				if (rs != null)
					rs.close();
				if (ps != null)
					ps.close();
				if (conn != null)
					conn.close();
			} catch (SQLException e) {
				LOGGER.error(e);
				throw new SbmException("Error during execution of finally block !");

			}
		}
		return flag;
	}


	public int createFolderByName(int parentFolderIndex, String FolderName, String sessionId) {
		xmlResponse
		.setXmlString(api.createFolder(parentFolderIndex, FolderName, sessionId));
		LOGGER.debug("Lead Folder Created ::" + FolderName);
		int data = Integer.parseInt(xmlResponse.getVal("FolderIndex"));
		LOGGER.debug("data= " + data);
		return data;
	}
	/*
	 * public boolean isDocumentExist(int leadfolder) { flag = 0; Connection conn =
	 * null; PreparedStatement ps = null; ResultSet rs = null; int folderIndex = 0;
	 * LOGGER.debug("leadfolder= " + leadfolder); try { conn =
	 * dbCon.getConnection(); LOGGER.debug("conn= " + conn); Document d = (Document)
	 * dd; ps = conn.prepareStatement(generalFolderIdQuery); ps.setInt(1,
	 * parentFolderIndex); rs = ps.executeQuery(); while (rs.next()) { if
	 * (rs.getString(1).equals(d.getApplicantName())) { flag++; // Addition on June
	 * 13 folderIndex = rs.getInt(3); break; } } if(flag== -1) { return flag; } else
	 * if (flag == 0) { data=createFolderByName(parentFolderIndex,
	 * d.getApplicantName(), sessionId); LOGGER.debug("Lead Folder " +
	 * d.getApplicantName()+" created with index= "+data);
	 * 
	 * } else{ data = folderIndex; }
	 * 
	 * } catch (SQLException e) { LOGGER.error(e); } finally { try { if (rs != null)
	 * rs.close(); if (ps != null) ps.close(); if (conn != null) conn.close(); }
	 * catch (SQLException e) { LOGGER.error(e); } }
	 * 
	 * return false; }
	 */}
