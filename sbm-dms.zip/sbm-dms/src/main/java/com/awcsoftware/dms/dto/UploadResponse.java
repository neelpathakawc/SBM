/**
 * 
 */
package com.awcsoftware.dms.dto;

import org.springframework.stereotype.Component;

/**
 * @author Shuaib
 *
 */
@Component
public class UploadResponse {

	private int docId;
	private String status;
	private int imageIndex;
	private float documentVersion;

	public UploadResponse() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param docId
	 * @param status
	 */
	public UploadResponse(int docId, String status, int imageIndex) {
		super();
		this.docId = docId;
		this.status = status;
		this.imageIndex = imageIndex;
	}

	/**
	 * @return the docId
	 */
	public int getDocId() {
		return docId;
	}

	/**
	 * @param docId the docId to set
	 */
	public void setDocId(int docId) {
		this.docId = docId;
	}

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * @return the imageIndex
	 */
	public int getImageIndex() {
		return imageIndex;
	}

	/**
	 * @param imageIndex the imageIndex to set
	 */
	public void setImageIndex(int imageIndex) {
		this.imageIndex = imageIndex;
	}
	
	public float getDocumentVersion() {
		return documentVersion;
	}

	public void setDocumentVersion(float documentVersion) {
		this.documentVersion = documentVersion;
	}

	@Override
	public String toString() {
		return "UploadResponse [docId=" + docId + ", status=" + status + ", imageIndex=" + imageIndex
				+ ", documentVersion=" + documentVersion + "]";
	}

	

}
