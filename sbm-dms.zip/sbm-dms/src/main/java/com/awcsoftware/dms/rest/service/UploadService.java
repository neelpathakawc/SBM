/**
 * 
 */
package com.awcsoftware.dms.rest.service;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Vector;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.awcsoftware.dms.api.DmsApi;
import com.awcsoftware.dms.api.UploadDocument;
import com.awcsoftware.dms.dto.BaseData;
import com.awcsoftware.dms.dto.UploadResponse;

/**
 * @author Shuaib
 *
 */
@Service
public class UploadService {
	final static Logger LOGGER = Logger.getLogger(UploadService.class);
	@Autowired
	private DmsApi api;
	@Autowired
	private UploadDocument ud;

	/*
	 * @Autowired public UploadService(DmsApi api, UploadDocument ud) { this.api =
	 * api; this.ud = ud; }
	 */

	/*
	 * static <T> void fromArrayToCollection(T[] a, Collection<T> c) { for (T o : a)
	 * { c.add(o); // Correct } }
	 */
	public List<UploadResponse> uploadDocument(ArrayList<? extends BaseData> bd, String sessionId) {
		LOGGER.info("dd= " + bd + " sessionId= " + sessionId + "\tdd.size= " + bd.size());
		ArrayList<UploadResponse> responseList = new ArrayList<UploadResponse>();
		UploadResponse ur;
//		BaseData data;
		for (BaseData ddx : bd) {
			ur = ud.upload(ddx, sessionId);
			LOGGER.debug("ur= " + ur);
			responseList.add(ur);
		}
		LOGGER.debug("Disconnect Call From DownloadService ::" + api.disconnect(sessionId));
		LOGGER.debug("responseList " + responseList);
		return responseList;
	}

}
