

/**
 * 
 */
package com.awcsoftware.dms.dto;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

/**
 * @author Shuaib
 *
 */
public class UserData {
	@NotBlank(message = "Username could not be blank")
	private String username;
	@Size(min = 8, max = 30, message = "Password must be equal or greater than 8 characters!")
	@NotBlank(message = "User Password could not be blank")
	private String userPassword;

	/**
	 * 
	 */
	public UserData() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param username
	 * @param userpassword
	 */
	public UserData(String username, String userpassword) {
		super();
		this.username = username;
		this.userPassword = userpassword;
	}

	/**
	 * @return the username
	 */
	public String getUsername() {
		return username;
	}

	/**
	 * @param username the username to set
	 */
	public void setUsername(String username) {
		this.username = username;
	}

	/**
	 * @return the userpassword
	 */
	public String getUserpassword() {
		return userPassword;
	}

	/**
	 * @param userpassword the userpassword to set
	 */
	public void setUserPassword(String userpassword) {
		this.userPassword = userpassword;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((username == null) ? 0 : username.hashCode());
		result = prime * result + ((userPassword == null) ? 0 : userPassword.hashCode());
		return result;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		UserData other = (UserData) obj;
		if (username == null) {
			if (other.username != null)
				return false;
		} else if (!username.equals(other.username))
			return false;
		if (userPassword == null) {
			if (other.userPassword != null)
				return false;
		} else if (!userPassword.equals(other.userPassword))
			return false;
		return true;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "UserData [username=" + username + ", userpassword=" + userPassword + "]";
	}

}
