/**
 * 
 */
package com.awcsoftware.dms.rest.service;

import java.util.ArrayList;

import javax.validation.constraints.Digits;
import javax.validation.constraints.NotEmpty;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.awcsoftware.dms.api.DmsApi;
import com.awcsoftware.dms.api.DownloadDocument;
import com.awcsoftware.dms.dto.BinaryData;
import com.awcsoftware.dms.dto.DownloadMetaData;
import com.awcsoftware.exception.SbmException;

/**
 * @author Shuaib
 *
 */
@Service
public class DownloadService {
	final static Logger LOGGER = Logger.getLogger(DownloadService.class);
	SbmDBOperations dbOps;

	@Autowired
	public DownloadService(SbmDBOperations dbOps) {
		super();
		this.dbOps = dbOps;
	}

	@Autowired
	DmsApi api;
	@Autowired
	DownloadDocument dd;
	ArrayList<BinaryData> al;

	/**
	 * 
	 */
	/*
	 * public ArrayList<BinaryData> downloadDocuments(String sessionId, String
	 * documents) { LOGGER.
	 * info("Entered downloadDocuments method \t Session ID From HeadParam ::" +
	 * sessionId);
	 * 
	 * if (dbOps.validateSessionId(sessionId)) { al = new ArrayList<BinaryData>();
	 * LOGGER.debug("documents : " + documents); String[] arr =
	 * documents.split(","); for (String str : arr) {
	 * al.add(dd.documentDownload(Integer.parseInt(str), sessionId)); }
	 * LOGGER.info("Disconnect Call From DownloadService ::" +
	 * api.disconnect(sessionId)); BinaryData bd = al.get(0);
	 * LOGGER.debug("binary data= " + bd); return al; } else { al = new
	 * ArrayList<BinaryData>(); al.add(new BinaryData(0, null,
	 * "Invalid Session Id")); return al; }
	 * 
	 * }
	 */

	public ArrayList<BinaryData> downloadDocuments(String sessionId, DownloadMetaData dmList) {
		LOGGER.info("Entered downloadDocuments method \t Session ID From HeadParam ::" + sessionId);
		if (dbOps.validateSessionId(sessionId)) {
			al = new ArrayList<BinaryData>();
			LOGGER.debug("dm : " + dmList);
			al.addAll(dd.downloadDocument(sessionId, dmList));
			LOGGER.info("Disconnect Call From DownloadService ::" + api.disconnect(sessionId));
			if(al.size()==0) {
				throw new SbmException("No documents found !");
			}
			BinaryData bd = al.get(0);
			LOGGER.debug("binary data= " + bd);
			return al;
		} else {
			al = new ArrayList<BinaryData>();
			al.add(new BinaryData(0, null, "Invalid Session Id"));
			return al;
		}
	}
}