package com.awcsoftware.dms.parambeans;
/**
 * 
 */
/*
 * 
 * package com.awcsoftware.dms.parambeans;
 * 
 * import org.springframework.util.MultiValueMap; import
 * org.springframework.web.bind.annotation.RequestHeader; import
 * org.springframework.web.bind.annotation.RequestPart;
 * 
 *//**
	 * @author Shuaib
	 *
	 */
/*
 * 
 * public class VersionDocumentParamBeans {
 * 
 * // @PathParam("documentId") String documentId;
 * 
 * 
 * String sessionid; MultiValueMap<String, String> mvp;
 * 
 * public VersionDocumentParamBeans() { }
 * 
 *//**
	 * @param documentId
	 * @param sessionid
	 */
/*
 * 
 * public VersionDocumentParamBeans(String documentId, String sessionid) {
 * super(); this.documentId = documentId; this.sessionid = sessionid; }
 * 
 *//**
	 * @return the documentId
	 */
/*
 * 
 * public String getDocumentId() { return documentId; }
 * 
 *//**
	 * @param documentId the documentId to set
	 */
/*
 * 
 * public void setDocumentId(String documentId) { this.documentId = documentId;
 * }
 * 
 *//**
	 * @return the sessionid
	 */
/*
 * 
 * public String getSessionid() { return sessionid; }
 * 
 *//**
	 * @param sessionid the sessionid to set
	 */
/*
 * public void setSessionid(String sessionid) { this.sessionid = sessionid; }
 * 
 *//**
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#hashCode()
	 */
/*
 * //
 * 
 * @Override public int hashCode() { final int prime = 31; int result = 1;
 * result = prime * result + ((documentId == null) ? 0 : documentId.hashCode());
 * result = prime * result + ((sessionid == null) ? 0 : sessionid.hashCode());
 * return result; }
 * 
 *//**
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
/*
 * 
 * @Override public boolean equals(Object obj) { if (this == obj) return true;
 * if (obj == null) return false; if (getClass() != obj.getClass()) return
 * false; VersionDocumentParamBeans other = (VersionDocumentParamBeans) obj; if
 * (documentId == null) { if (other.documentId != null) return false; } else if
 * (!documentId.equals(other.documentId)) return false; if (sessionid == null) {
 * if (other.sessionid != null) return false; } else if
 * (!sessionid.equals(other.sessionid)) return false; return true; }
 * 
 *//**
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 *//*
		 * 
		 * @Override public String toString() { return
		 * "VersionDocumentParamBeans [documentId=" + documentId + ", sessionid=" +
		 * sessionid + "]"; }
		 * 
		 * }
		 */