/**
 * 
 */
package com.awcsoftware.dms.api;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.awcsoftware.base64.EncryptionOppo;
import com.awcsoftware.bytes.BytesConvertion;
import com.awcsoftware.dms.dto.BinaryData;
import com.awcsoftware.dms.dto.DownloadMetaData;
import com.awcsoftware.spring.data.jpa.ConnectSbmDB;
import com.newgen.dmsapi.DMSXmlResponse;

import ISPack.CPISDocumentTxn;
import ISPack.ISUtil.JPISException;
import Jdts.DataObject.JPDBString;

/**
 * @author Shuaib
 *
 */
@Service
//@Scope("prototype")
public class DownloadDocument {
	final static Logger LOGGER = Logger.getLogger(DownloadDocument.class);
	private EncryptionOppo esk;
	private ByteArrayOutputStream streamBuff;
	private JPDBString siteName;
	private DmsProperties pp;
	@Autowired
	private ConnectSbmDB dbconn;

	/**
	 * 
	 */
	public DownloadDocument(EncryptionOppo esk, DmsProperties pp) {
		this.esk = esk;
		this.pp = pp;
	}

	public BinaryData documentDownload(int imgIndex, String sessionId) {
		LOGGER.info("Enterd documentDownload method");
		siteName = new JPDBString();
		streamBuff = new ByteArrayOutputStream();
		System.out.println("Session ID From  DownloadDocument Call :: " + sessionId);
		Byte[] data = null;
		BinaryData bd = new BinaryData();
		try {

			CPISDocumentTxn.GetDocInFile_MT(null, pp.getServerIP(), (short) 3333, pp.getCabinateName(), (short) 1,
					(short) 1, imgIndex, sessionId, streamBuff, siteName);
			LOGGER.debug("streamBuff.toByteArray()= " + streamBuff.toByteArray());
			/*
			 * for (byte b : streamBuff.toByteArray()) { LOGGER.info("b=" + b); }
			 */
			data = esk.encodeData(streamBuff.toByteArray());
			LOGGER.info("After encodeData() data is=" + data);

			/*
			 * for (byte b : data) { LOGGER.info("b=" + b); }
			 */
			streamBuff.flush();
			streamBuff.close();

		} catch (JPISException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		bd.setimageIndex(imgIndex);
		bd.setData(data);
		return bd;
	}

	@SuppressWarnings("null")
	public ArrayList<BinaryData> downloadDocument(String sessionId, DownloadMetaData dm) {
		LOGGER.info("Entered downloadDocument method ");
		ArrayList<BinaryData> bdList=new ArrayList<>();
		if (dm.getImgIndex() != 0) {
			bdList.add(documentDownload(dm.getImgIndex(), sessionId));
		} else {
			ArrayList<Integer> docIdList=	getDocumentList(dm);
			ArrayList<Integer> imgIdList=new ArrayList<>();
			for(int docIndex:docIdList ) {
			String imageIndexListQuery="select ImageIndex from PDBDocument where DocumentIndex=?";
			try {
				Connection conn = dbconn.getConnection();
				PreparedStatement ps = conn.prepareStatement(imageIndexListQuery, ResultSet.TYPE_SCROLL_INSENSITIVE,
						ResultSet.CONCUR_READ_ONLY);
				ps.setInt(1, docIndex);
				ResultSet rs = ps.executeQuery();
				if (rs.next() == false) {
					LOGGER.info("Empty ResultSet !");
				} else {
					rs.beforeFirst();
					while (rs.next()) {
						imgIdList.add(rs.getInt(1));
					}
				}
			} catch (SQLException e) {
				LOGGER.warn(e);
			}					
			}
			LOGGER.debug("imgIdList= "+imgIdList);
			for(int imgIndex:imgIdList) {
				bdList.add(documentDownload(imgIndex, sessionId));
			}
		}
		LOGGER.debug("bdList.size= "+bdList.size());
		return bdList;
	}

	public ArrayList<Integer> getDocumentList(DownloadMetaData dm) {
		LOGGER.info("Entered methodgetDocumentList");
		ArrayList<Integer> al = new ArrayList<>();
		Map<String, String> dmMap = new HashMap<>();
		StringBuilder query = new StringBuilder("select FoldDocIndex from ddt_3 where ");

		if (!dm.getCifId().isEmpty()) {
			dmMap.put(dm.getCifId(), "Field_9");
		}
		if (!dm.getAccountNumber().isEmpty()) {
			dmMap.put(dm.getAccountNumber(), "Field_10");
		}
		if (!dm.getAccountType().isEmpty()) {
			dmMap.put(dm.getAccountType(), "Field_11");
		}
		if (!dm.getDocType().isEmpty()) {
			dmMap.put(dm.getDocType(), "Field_12");
		}
		if (!dm.getDocN().isEmpty()) {
			dmMap.put(dm.getDocN(), "Field_13");
		}
		if (!dm.getApplicantName().isEmpty()) {
			dmMap.put(dm.getApplicantName(), "Field_14");
		}
		boolean flag = true;

//		ArrayList<String> values=(ArrayList<String>) dmMap.values();
//		LOGGER.debug("values= "+values);

		Set<String> keys = dmMap.keySet();
		LOGGER.debug("Set keys= " + keys);
		for (String key : keys) {
			if (flag == true) {
				String value = dmMap.get(key);
				LOGGER.debug("value= " + value + "  key= " + key);
				query.append(value + "='" + key + "' ");
				flag = false;
			} else {
				query.append(" AND " + dmMap.get(key) + "='" + key + "' ");
			}
		}
		LOGGER.debug("Final Query= " + query);
		try {
			Connection conn = dbconn.getConnection();
			PreparedStatement ps = conn.prepareStatement(query.toString(), ResultSet.TYPE_SCROLL_INSENSITIVE,
					ResultSet.CONCUR_READ_ONLY);
//			ps.setInt(1, docId);
			ResultSet rs = ps.executeQuery();
			if (rs.next() == false) {
				LOGGER.info("Empty ResultSet !");
				al.add(0);
			} else {
				rs.beforeFirst();
				while (rs.next()) {
					al.add(rs.getInt(1));
				}
			}
		} catch (SQLException e) {
			LOGGER.warn(e);
		}
		LOGGER.debug("Data from Table :" + al);
		return al;
	}

	public static void main(String[] args) {
		LOGGER.info("Inside Main of Download Document");
		BytesConvertion bc = new BytesConvertion();
		EncryptionOppo eo = new EncryptionOppo();
		LOGGER.info("BytesConvertion, EncryptionOppo Object Created");
		Byte[] bv = eo.encodeData(bc.convertToByteData("D:\\General\\dummy.pdf"));
		LOGGER.info("encodeData() called bv.toString() is= " + bv.toString());
		System.out.println("Bytes Data size= " + bv.length);
		for (byte b : bv) {
			System.out.print(b + ", ");
		}
		System.out.println();
		// UploadDocument ud = new UploadDocument(); //

//		DocumentData dd = new DocumentData("999", "99", "9", "xlsx", "OPPO_MOM.xlsx", "LO", bv); //
//		logger.info("DocumentData dd= " + dd); //
//		ud.upload(dd, "722598168");
//		logger.info("ud.upload()");
		/*
		 * if(!dm.getCifId().isEmpty()) { query.append("Field_66='"+dm.getCifId()+"'");
		 * } if( !dm.getCifId().isEmpty() && !dm.getAccountNumber().isEmpty()) {
		 * query.append("AND Field_67='"+dm.getAccountNumber()+"'"); }else
		 * if(!dm.getAccountNumber().isEmpty()) {
		 * query.append("Field_67='"+dm.getAccountNumber()+"'"); }
		 * 
		 * 
		 * if( !dm.getCifId().isEmpty() || !dm.getAccountNumber().isEmpty()) {
		 * if(!dm.getAccountType().isEmpty()) {
		 * query.append(" AND Field_68='"+dm.getAccountType()+"'"); } }
		 * if(!dm.getDocType().isEmpty()) {
		 * query.append("Field_69='"+dm.getDocType()+"'"); }
		 * 
		 * if(!dm.getDocN().isEmpty()) { query.append("Field_70='"+dm.getDocN()+"'"); }
		 * if(!dm.getApplicantName().isEmpty()) {
		 * query.append("Field_71='"+dm.getApplicantName()+"'"); }
		 * 
		 */
	}
}
