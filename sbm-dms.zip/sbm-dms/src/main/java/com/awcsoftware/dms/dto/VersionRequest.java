/**
 * 
 */
package com.awcsoftware.dms.dto;

import java.util.Arrays;

/**
 * @author shuaib
 *
 */
public class VersionRequest {
	private int docId;
	private String ext;
	private String comment;
	private byte[] data;

	/**
	 * 
	 */
	public VersionRequest() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param docId
	 * @param data
	 * @param ext
	 * @param comment
	 */
	public VersionRequest(int docId, String ext, String comment, byte[] data) {
		super();
		this.docId = docId;
		this.data = data;
		this.ext = ext;
		this.comment = comment;
	}

	/**
	 * @return the docId
	 */
	public int getDocId() {
		return docId;
	}

	/**
	 * @param docId the docId to set
	 */
	public void setDocId(int docId) {
		this.docId = docId;
	}

	/**
	 * @return the data
	 */
	public byte[] getData() {
		return data;
	}

	/**
	 * @param data the data to set
	 */
	public void setData(byte[] data) {
		this.data = data;
	}

	/**
	 * @return the ext
	 */
	public String getExt() {
		return ext;
	}

	/**
	 * @param ext the ext to set
	 */
	public void setExt(String ext) {
		this.ext = ext;
	}

	/**
	 * @return the comment
	 */
	public String getComment() {
		return comment;
	}

	/**
	 * @param comment the comment to set
	 */
	public void setComment(String comment) {
		this.comment = comment;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((comment == null) ? 0 : comment.hashCode());
		result = prime * result + Arrays.hashCode(data);
		result = prime * result + docId;
		result = prime * result + ((ext == null) ? 0 : ext.hashCode());
		return result;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		VersionRequest other = (VersionRequest) obj;
		if (comment == null) {
			if (other.comment != null)
				return false;
		} else if (!comment.equals(other.comment))
			return false;
		if (!Arrays.equals(data, other.data))
			return false;
		if (docId != other.docId)
			return false;
		if (ext == null) {
			if (other.ext != null)
				return false;
		} else if (!ext.equals(other.ext))
			return false;
		return true;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "VersionRequest [docId=" + docId + ", data=" + Arrays.toString(data) + ", ext=" + ext + ", comment="
				+ comment + "]";
	}

}
