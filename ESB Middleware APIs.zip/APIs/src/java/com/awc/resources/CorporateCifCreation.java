/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.awc.resources;

import com.awc.methods.General;
import com.awc.methods.LogProcessing;
import com.awc.methods.SBMCalling;
import com.awc.methods.SBM_getSession;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Properties;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PUT;
import javax.ws.rs.core.MediaType;

/**
 * REST Web Service
 *
 * @author Admin
 */
@Path("CorporateCifCreation")
public class CorporateCifCreation {

    @Context
    private UriInfo context;

    /**
     * Creates a new instance of CorporateCifCreation
     */
    public CorporateCifCreation() {
    }

    /**
     * Retrieves representation of an instance of
     * com.awc.resources.CorporateCifCreation
     *
     * @return an instance of java.lang.String
     */
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public String getJson() {
        //TODO return proper representation object
        throw new UnsupportedOperationException();
    }

    /**
     * PUT method for updating or creating an instance of CorporateCifCreation
     *
     * @param content representation for the resource
     */
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public String putJson(@HeaderParam("PARTNERNAME") String partname, String content) {
        LogProcessing.settingLogFiles();
        General obj = new General();
        LogProcessing.corporatecifcreation.info("JSON Input::: " + content);
        String inputxml = "", finalinputxml = "", url = "";;
        try {
            String currentdir = System.getProperty("user.dir");
            String filePath = currentdir + File.separator + "property" + File.separator + "conf.properties";
            LogProcessing.corporatecifcreation.info("filepath is:::" + filePath);
            InputStream is = new FileInputStream(filePath);

            Properties prop = new Properties();

            prop.load(is);
            is.close();

            inputxml = obj.JsontoXML(content);
            LogProcessing.corporatecifcreation.info("xmlinput for cifReatilEnquiry:::" + inputxml);
            finalinputxml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>"
                    + "<FIXML xsi:schemaLocation=\"http://www.finacle.com/fixml createCorporateCustomer.xsd\" "
                    + "xmlns=\"http://www.finacle.com/fixml\""
                    + " xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">" + inputxml + "</FIXML>";

            LogProcessing.corporatecifcreation.info("xmlinputfinal for cifReatilEnquiry::: " + finalinputxml);

            url = prop.getProperty("CorporateCifCreation");
            LogProcessing.corporatecifcreation.info("url is::::" + url);
        } catch (Exception e) {
            LogProcessing.error.info("Error Occured..!!!! " + e);
        }
        SBMCalling sbmcalling = new SBMCalling();
        SBM_getSession sessionObj = new SBM_getSession();
        String sessionid = sessionObj.getESBSessionID(partname);

        String outputxml = sbmcalling.callingSBMHeadercif(finalinputxml, url, partname, sessionid);
        LogProcessing.corporatecifcreation.info("output xml data is::::" + outputxml);
        String outputjson = "";
        outputjson = obj.XMLtoJSON(outputxml);
        LogProcessing.corporatecifcreation.info("output json data is::::" + outputjson);
        return outputjson;

    }
}
