/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.awc.resources;

import com.awc.bean.SBMCIFCreationBean;
import com.awc.methods.General;
import com.awc.methods.LogProcessing;
import com.awc.methods.SBMCalling;
import com.awc.methods.SBM_createcif;
import com.awc.methods.SBM_getSession;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Properties;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.MediaType;

/**
 * REST Web Service
 *
 * @author Saurish
 */
@Path("RetailCifCreation")
public class RetailCIFCreationResource {

    @Context
    private UriInfo context;

    /**
     * Creates a new instance of RetailCIFCreationResource
     */
    public RetailCIFCreationResource() {
    }

    /**
     * Retrieves representation of an instance of
     * com.awc.resources.RetailCIFCreationResource
     *
     * @return an instance of java.lang.String
     */
    @GET
    @Produces(MediaType.APPLICATION_XML)
    public String getXml() {
        //TODO return proper representation object
        throw new UnsupportedOperationException();
    }

    /**
     * PUT method for updating or creating an instance of
     * RetailCIFCreationResource
     *
     * @param partname represents PARTNERNAME
     * @param sessionid represents SESSIONID
     * @param content representation for the resource
     */
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public String putXml(@HeaderParam("PARTNERNAME") String partname, String content) {

        LogProcessing.settingLogFiles();
        General objGeneral = new General();
        String xmlinput = objGeneral.JsontoXML(content);
        String urltosend = "";
        SBM_getSession sessionObj = new SBM_getSession();
        String sessionid = sessionObj.getESBSessionID(partname);
        LogProcessing.cifcreation.info("Header Partner Name ::: " + partname);
        LogProcessing.cifcreation.info("Header Session ID ::: " + sessionid);
        try {
            InputStream is = null;
            String currentdir = System.getProperty("user.dir");
            String filePath = currentdir + File.separator + "property" + File.separator + "conf.properties";
            System.out.println(filePath);
            is = new BufferedInputStream(new FileInputStream(filePath));
            Properties ps = new Properties();
            ps.load(is);
            is.close();
            urltosend = ps.getProperty("CIFCreationURL");
        } catch (Exception e) {
            LogProcessing.error.info("Error Occured..!!! " + e);
        }
        SBMCalling callsbm = new SBMCalling();
        String outputxml = callsbm.callingSBMHeadercif(xmlinput, urltosend, partname, sessionid);
        LogProcessing.cifcreation.info("Response from SBM :::: " + outputxml);
        SBMCIFCreationBean obj = new SBMCIFCreationBean();
        SBM_createcif cif = new SBM_createcif();
        obj = cif.cifSBMParse(outputxml);

        return new SBM_createcif().cifcreationOutput(obj);
    }
}
