/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.awc.resources;

import com.awc.methods.General;
import com.awc.methods.LogProcessing;
import com.awc.methods.SBMCalling;
import com.awc.methods.SBM_getSession;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.UriInfo;
import org.json.JSONObject;

/**
 * REST Web Service
 *
 * @author Admin
 */
@Path("AccountAvailability")
public class AccountAvailability {

    @Context
    private UriInfo context;

    /**
     * Creates a new instance of AccountAvailability
     */
    public AccountAvailability() {
    }

    /**
     * Retrieves representation of an instance of
     * com.awc.resources.AccountAvailability
     *
     * @return an instance of java.lang.String
     */
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public String getJson() {
        //TODO return proper representation object
        throw new UnsupportedOperationException();
    }

    /**
     * PUT method for updating or creating an instance of AccountAvailability
     *
     * @param content representation for the resource
     */
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public String putJson(@HeaderParam("PARTNERNAME") String partname, String content)  {
         LogProcessing.settingLogFiles();
         String servicerequestid ="";
          LogProcessing.accountAvailability.info("JSON Input::: " + content);
        try {
            JSONObject object1 = new JSONObject(content);
            JSONObject obj1 = object1.getJSONObject("Header");
            JSONObject obj2 = obj1.getJSONObject("RequestHeader");
            JSONObject obj3 = obj2.getJSONObject("MessageKey");
            servicerequestid = obj3.optString("ServiceRequestId");
        } catch (Exception e) {
           LogProcessing.error.info("Error Occured..!!!! " + e);
        }

        General obj = new General();
        
        SBM_getSession sessionObj = new SBM_getSession();
        String sessionid = sessionObj.getESBSessionID(partname);
        
        LogProcessing.accountAvailability.info("Header Partner Name ::: " + partname);
        LogProcessing.accountAvailability.info("Header Session ID ::: " + sessionid);

         String inputxml = "", finalinputxml = "",url = "";;
        try{
        String currentdir = System.getProperty("user.dir");
        String filePath = currentdir + File.separator + "property" + File.separator + "conf.properties";
         LogProcessing.accountAvailability.info("filepath is:::"+filePath);
        InputStream is = new FileInputStream(filePath);

        Properties prop = new Properties();

        prop.load(is);
        is.close();
      
 
        inputxml = obj.JsontoXML(content);
        LogProcessing.accountAvailability.info("inputxml  is:::"+inputxml);
       
        if (servicerequestid.equals("SBAcctInq")) {

            finalinputxml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>"
                    + "<FIXML xsi:schemaLocation=\"http://www.finacle.com/fixml SBAcctInq.xsd\""
                    + " xmlns=\"http://www.finacle.com/fixml\" "
                    + "xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">"
                    + inputxml + "</FIXML>";

            LogProcessing.accountAvailability.info("finalinputxmlsb  is:::"+finalinputxml);

            url = prop.getProperty("SavingAccountEnquiry");
            LogProcessing.accountAvailability.info("urlsb  is:::"+url);
        } else if (servicerequestid.equals("CAAcctInq")) {
            finalinputxml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>"
                    + "<FIXML xsi:schemaLocation=\"http://www.finacle.com/fixml CAAcctInq.xsd\" "
                    + "xmlns=\"http://www.finacle.com/fixml\""
                    + " xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">"
                    + inputxml + "</FIXML>";

             LogProcessing.accountAvailability.info("finalinputxmlca  is:::"+finalinputxml);

            url = prop.getProperty("CurrentAccountEnquiry");
             LogProcessing.accountAvailability.info("urlca  is:::"+url);
        } else if (servicerequestid.equals("ODAcctInq")) {
            finalinputxml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>"
                    + "<FIXML xsi:schemaLocation=\"http://www.finacle.com/fixml ODAcctInq.xsd\" "
                    + "xmlns=\"http://www.finacle.com/fixml\" "
                    + "xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">"
                    + inputxml + "</FIXML>";

           LogProcessing.accountAvailability.info("finalinputxmlod  is:::"+finalinputxml);

            url = prop.getProperty("OverdraftAccountEnquiry");
             LogProcessing.accountAvailability.info("urlod  is:::"+url);
        } else if (servicerequestid.equals("TDAcctInq")) {
            finalinputxml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>"
                    + "<FIXML xsi:schemaLocation=\"http://www.finacle.com/fixml TDAcctInq.xsd\" "
                    + "xmlns=\"http://www.finacle.com/fixml\""
                    + " xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">"
                    + inputxml + "</FIXML>";

             LogProcessing.accountAvailability.info("finalinputxmltd  is:::"+finalinputxml);

            url = prop.getProperty("TDAccountEnquiry");
           LogProcessing.accountAvailability.info("urltd  is:::"+url);
        } else if (servicerequestid.equals("LoanAcctInq")) {
            finalinputxml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>"
                    + "<FIXML xsi:schemaLocation=\"http://www.finacle.com/fixml LoanAcctInq.xsd\" "
                    + "xmlns=\"http://www.finacle.com/fixml\" "
                    + "xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">"
                    + inputxml + "</FIXML>";

           LogProcessing.accountAvailability.info("finalinputxmlloan  is:::"+finalinputxml);

            url = prop.getProperty("LoanAccountEnquiry");
            LogProcessing.accountAvailability.info("urlloan  is:::"+url);
        }
        }catch(Exception e){
             LogProcessing.error.info("Error Occured..!!! " + e);
        }
        SBMCalling obj5 = new SBMCalling();
        String outputxml = "";
        outputxml = obj5.callingSBMHeadercif(finalinputxml, url, partname, sessionid);
      
         LogProcessing.accountAvailability.info("Response from SBM in xml :::: " + outputxml);
        String outputjson = "";
        outputjson = obj.XMLtoJSON(outputxml);
         LogProcessing.accountAvailability.info("Outputjson is :::: " + outputjson);
        return outputjson;

    }
}
