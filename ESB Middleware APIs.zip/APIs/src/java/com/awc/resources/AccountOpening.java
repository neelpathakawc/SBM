/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.awc.resources;

import com.awc.methods.General;
import com.awc.methods.LogProcessing;
import com.awc.methods.SBMCalling;
import com.awc.methods.SBM_getSession;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Properties;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PUT;
import javax.ws.rs.core.MediaType;
import org.json.JSONObject;

/**
 * REST Web Service
 *
 * @author Admin
 */
@Path("AccountOpening")
public class AccountOpening {

    @Context
    private UriInfo context;

    /**
     * Creates a new instance of AccountOpening
     */
    public AccountOpening() {
    }

    /**
     * Retrieves representation of an instance of
     * com.awc.resources.AccountOpening
     *
     * @return an instance of java.lang.String
     */
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public String getJson() {
        //TODO return proper representation object
        throw new UnsupportedOperationException();
    }

    /**
     * PUT method for updating or creating an instance of AccountOpening
     *
     * @param content representation for the resource
     */
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public String putJson(@HeaderParam("PARTNERNAME") String partname, String content) {

        LogProcessing.settingLogFiles();
        String servicerequestid = "";
        LogProcessing.accountopening.info("JSON Input::: " + content);
        try {
            JSONObject object1 = new JSONObject(content);
            JSONObject obj1 = object1.getJSONObject("Header");
            JSONObject obj2 = obj1.getJSONObject("RequestHeader");
            JSONObject obj3 = obj2.getJSONObject("MessageKey");
            servicerequestid = obj3.optString("ServiceRequestId");
        } catch (Exception e) {
            LogProcessing.error.info("Error Occured..!!!! " + e);
        }

        General obj = new General();

        SBM_getSession sessionObj = new SBM_getSession();
        String sessionid = sessionObj.getESBSessionID(partname);

        LogProcessing.accountopening.info("Header Partner Name ::: " + partname);
        LogProcessing.accountopening.info("Header Session ID ::: " + sessionid);

        String inputxml = "", finalinputxml = "", url = "";;
        try {
            String currentdir = System.getProperty("user.dir");
            String filePath = currentdir + File.separator + "property" + File.separator + "conf.properties";
            LogProcessing.accountopening.info("filepath is:::" + filePath);
            InputStream is = new FileInputStream(filePath);

            Properties prop = new Properties();

            prop.load(is);
            is.close();

            inputxml = obj.JsontoXML(content);
            LogProcessing.accountopening.info("inputxml  is:::" + inputxml);

            if (servicerequestid.equals("SBAcctAdd")) {

                finalinputxml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>"
                        + "<FIXML xsi:schemaLocation=\"http://www.finacle.com/fixml SBAcctAdd.xsd\""
                        + " xmlns=\"http://www.finacle.com/fixml\" "
                        + "xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">"
                        + inputxml + "</FIXML>";

                LogProcessing.accountopening.info("finalinputxmlsb  is:::" + finalinputxml);

                url = prop.getProperty("SavingAccountOpening");
                LogProcessing.accountopening.info("urlsb  is:::" + url);
            } else if (servicerequestid.equals("CAAcctAdd")) {
                finalinputxml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>"
                        + "<FIXML xsi:schemaLocation=\"http://www.finacle.com/fixml CAAcctAdd.xsd\" "
                        + "xmlns=\"http://www.finacle.com/fixml\""
                        + " xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">"
                        + inputxml + "</FIXML>";

                LogProcessing.accountopening.info("finalinputxmlca  is:::" + finalinputxml);

                url = prop.getProperty("CurrentAccountOpening");
                LogProcessing.accountopening.info("urlca  is:::" + url);
            } else if (servicerequestid.equals("ODAcctAdd")) {
                finalinputxml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>"
                        + "<FIXML xsi:schemaLocation=\"http://www.finacle.com/fixml ODAcctAdd.xsd\" "
                        + "xmlns=\"http://www.finacle.com/fixml\" "
                        + "xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">"
                        + inputxml + "</FIXML>";

                LogProcessing.accountopening.info("finalinputxmlod  is:::" + finalinputxml);

                url = prop.getProperty("OverdraftAccountOpening");
                LogProcessing.accountopening.info("urlod  is:::" + url);
            } else if (servicerequestid.equals("TDAcctAdd")) {
                finalinputxml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>"
                        + "<FIXML xsi:schemaLocation=\"http://www.finacle.com/fixml TDAcctAdd.xsd\" "
                        + "xmlns=\"http://www.finacle.com/fixml\""
                        + " xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">"
                        + inputxml + "</FIXML>";

                LogProcessing.accountopening.info("finalinputxmltd  is:::" + finalinputxml);

                url = prop.getProperty("TDAccountOpening");
                LogProcessing.accountopening.info("urltd  is:::" + url);
            } else if (servicerequestid.equals("LoanAcctAdd")) {
                finalinputxml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>"
                        + "<FIXML xsi:schemaLocation=\"http://www.finacle.com/fixml LoanAcctAdd.xsd\" "
                        + "xmlns=\"http://www.finacle.com/fixml\" "
                        + "xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">"
                        + inputxml + "</FIXML>";

                LogProcessing.accountopening.info("finalinputxmlloan  is:::" + finalinputxml);

                url = prop.getProperty("LoanAccountOpening");
                LogProcessing.accountopening.info("urlloan  is:::" + url);
            }
        } catch (Exception e) {
            LogProcessing.error.info("Error Occured..!!! " + e);
        }
        SBMCalling obj5 = new SBMCalling();
        String outputxml = "";
        outputxml = obj5.callingSBMHeadercif(finalinputxml, url, partname, sessionid);

        LogProcessing.accountopening.info("Response from SBM in xml :::: " + outputxml);
        String outputjson = "";
        outputjson = obj.XMLtoJSON(outputxml);
        LogProcessing.accountopening.info("Outputjson is :::: " + outputjson);
        return outputjson;

    }

}
