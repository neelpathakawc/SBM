/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.awc.resources;

import com.awc.methods.General;
import com.awc.methods.LogProcessing;
import com.awc.methods.SBMCalling;
import com.awc.methods.SBM_getSession;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.Produces;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PUT;
import javax.ws.rs.core.MediaType;

/**
 * REST Web Service
 *
 * @author Admin
 */
@Path("CIFRetailInquiry")
public class CifRetailEnquiry {

    @Context
    private UriInfo context;

    /**
     * Creates a new instance of CifRetailEnquiry
     */
    public CifRetailEnquiry() {
    }

    /**
     * Retrieves representation of an instance of
     * com.awc.resources.CifRetailEnquiry
     *
     * @return an instance of java.lang.String
     */
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public String getJson() {
        //TODO return proper representation object
        throw new UnsupportedOperationException();
    }

    /**
     * PUT method for updating or creating an instance of CifRetailEnquiry
     *
     * @param content representation for the resource
     */
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public String putJson(@HeaderParam("PARTNERNAME") String partname, String content) {
        LogProcessing.settingLogFiles();
        General obj1 = new General();
        System.out.println("JSON Input::: " + content);
        //LogProcessing.cifretailenquiry.info("JSON Input::: " + content);

        String xmlinput = "", url = "";
        xmlinput = obj1.JsontoXML(content);
        LogProcessing.cifretailenquiry.info("xmlinput for cifReatilEnquiry:::" + xmlinput);
        String xmlinputfinal = "";
        xmlinputfinal = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>"
                + "<FIXML xsi:schemaLocation=\"http://www.finacle.com/fixml RetCustInq.xsd\" "
                + "xmlns=\"http://www.finacle.com/fixml\""
                + " xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">" + xmlinput + "</FIXML>";
        LogProcessing.cifretailenquiry.info("xmlinputfinal for cifReatilEnquiry::: " + xmlinputfinal);
        try {
            String currentdir = System.getProperty("user.dir");
            String filePath = currentdir + File.separator + "property" + File.separator + "conf.properties";
            LogProcessing.cifretailenquiry.info(filePath);
            InputStream is = new FileInputStream(filePath);

            Properties prop = new Properties();

            prop.load(is);

            url = prop.getProperty("CifRetailInquiry");
            LogProcessing.cifretailenquiry.info("url is::::" + url);
        } catch (Exception e) {
            LogProcessing.error.info("Error Occured..!!!! " + e);
        }

        SBM_getSession sessionObj = new SBM_getSession();
        String sessionid = sessionObj.getESBSessionID(partname);

        SBMCalling obj2 = new SBMCalling();
        String output = obj2.callingSBMHeadercif(xmlinputfinal, url, partname, sessionid);

        String outputjsondata = obj1.XMLtoJSON(output);
        LogProcessing.cifretailenquiry.info("output json data is::::" + outputjsondata);
        return outputjsondata;
    }
}
