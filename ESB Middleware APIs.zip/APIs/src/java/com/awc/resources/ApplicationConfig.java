/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.awc.resources;

import java.util.Set;
import javax.ws.rs.core.Application;

/**
 *
 * @author Saurish
 */
@javax.ws.rs.ApplicationPath("sbm-customer-account-services")
public class ApplicationConfig extends Application {

    @Override
    public Set<Class<?>> getClasses() {
        Set<Class<?>> resources = new java.util.HashSet<>();
        addRestResourceClasses(resources);
        return resources;
    }

    /**
     * Do not modify addRestResourceClasses() method.
     * It is automatically populated with
     * all resources defined in the project.
     * If required, comment out calling this method in getClasses().
     */
    private void addRestResourceClasses(Set<Class<?>> resources) {
        resources.add(com.awc.methods.SessionResource.class);
        resources.add(com.awc.resources.AccountAvailability.class);
        resources.add(com.awc.resources.AccountOpening.class);
        resources.add(com.awc.resources.CifRetailEnquiry.class);
        resources.add(com.awc.resources.CorporateCifCreation.class);
        resources.add(com.awc.resources.CorporateCifEnquiry.class);
        //resources.add(com.awc.resources.SessionResource.class);
        resources.add(com.awc.resources.RetailCIFCreationResource.class);
    }
    
}
