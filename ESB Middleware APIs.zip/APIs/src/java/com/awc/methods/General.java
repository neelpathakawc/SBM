/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.awc.methods;

import org.json.JSONException;
import org.json.JSONObject;
import org.json.XML;

/**
 *
 * @author Saurish
 */
public class General {

    public String JsontoXML(String json_data) throws JSONException {
        LogProcessing.settingLogFiles();
        JSONObject obj = new JSONObject(json_data);

        //converting json to xml
        String xml_data = XML.toString(obj);

        LogProcessing.cifcreation.info("JSON to XML ::: " + xml_data);
        return xml_data;
    }
    
      public String XMLtoJSON(String xmldata) {
        String jsondata = "";
        try {
            JSONObject json = XML.toJSONObject(xmldata);
            //   String jsonPrettyPrintString = json.toString(4); // json pretty print
            //System.out.println(jsonPrettyPrintString);
            jsondata = json.toString();
        } catch (JSONException je) {
            LogProcessing.error.info("Error in XML to JSON conversion :::: " + je.toString());
        }
        return jsondata;
    }

}
