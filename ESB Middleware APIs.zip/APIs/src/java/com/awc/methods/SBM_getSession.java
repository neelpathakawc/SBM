/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.awc.methods;

import com.awc.bean.SBMSessionIDBean;
import com.awc.bean.SessionIDBean;
import com.awc.xml.XMLParser;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Properties;
import java.util.Random;
import org.json.JSONObject;

/**
 *
 * @author Saurish
 */
public class SBM_getSession {

    XMLParser xmlParser = null;

    public String getESBSessionID(String partname) {
        LogProcessing.settingLogFiles();
        LogProcessing.sess.info("Partner Name ::: " + partname);
        AESEncryption aes = new AESEncryption();
        SessionIDBean objBean = new SessionIDBean();
        SBMSessionIDBean objsbm = new SBMSessionIDBean();
        String originalString = "<data>"
                + "<username>SBM_IBPS001</username>"
                + "<password>IBP$4321#</password>"
                + "</data>";
        String encrRequest = aes.encrypt(originalString);
        Random rand = new Random();
        long accumulator = 1 + rand.nextInt(9); // ensures that the 16th digit isn't 0
        for (int i = 0; i < 15; i++) {
            accumulator *= 10L;
            accumulator += rand.nextInt(10);
        }
        Timestamp time = new Timestamp(System.currentTimeMillis());

        objBean.setChannelId("SBM_IBPS");
        objBean.setPartnerReqID("IBPS_SBM_IBPS001_" + accumulator);
        objBean.setRequest(encrRequest);
        objBean.setTimeStamp(new SimpleDateFormat("yyyy-MM-dd hh:mm:ss").format(time));

        SBM_getSession m = new SBM_getSession();

        String sbmResponse = m.callSBMsession(objBean, partname);
        objsbm = m.getresponseSBMsession(sbmResponse);

        return new SBM_getSession().createSesssionJSON(objsbm);

    }

    public SessionIDBean parseNewgenRequest(String content) {
        SessionIDBean objBean = new SessionIDBean();
        JSONObject o = new JSONObject(content);
        objBean.setChannelId(o.optString("channelId"));
        objBean.setPartnerReqID(o.optString("PartnerReqID"));
        objBean.setRequest(o.optString("request"));
        objBean.setTimeStamp(o.optString("timestamp"));

        return objBean;
    }

    public String callSBMsession(SessionIDBean sessionobj, String partname) {

        String outputxml = "";
        String urltosend = "";

        String inputxml = "<sessionReq>"
                + "<channelId>" + sessionobj.getChannelId() + "</channelId> <PartnerReqID>" + sessionobj.getPartnerReqID() + "</PartnerReqID>"
                + "<timestamp>" + sessionobj.getTimeStamp() + "</timestamp>"
                + "<request>" + sessionobj.getRequest() + "</request>"
                + "</sessionReq>";
        LogProcessing.sess.info("SBM Session Input XML :::: " + inputxml);
        SBMCalling ca = new SBMCalling();
        try {
            InputStream is = null;
            String currentdir = System.getProperty("user.dir");
            String filePath = currentdir + File.separator + "property" + File.separator + "conf.properties";
            System.out.println(filePath);
            is = new BufferedInputStream(new FileInputStream(filePath));
            Properties ps = new Properties();
            ps.load(is);
            is.close();
            urltosend = ps.getProperty("SessionURL");
        } catch (Exception e) {
            LogProcessing.error.info("Error Occured..!!! " + e);
        }
        outputxml = ca.callingSBM(inputxml, urltosend, partname);
        LogProcessing.sess.info("SBM Session Output XML ::: " + outputxml);
        return outputxml;
    }

    public SBMSessionIDBean getresponseSBMsession(String outputxml) {
        SBMSessionIDBean objsbm = new SBMSessionIDBean();
        xmlParser = new XMLParser();
        xmlParser.setInputXML(outputxml);

        if ("Success".equalsIgnoreCase(xmlParser.getValueOf("Status"))) {
            objsbm.setStatus(xmlParser.getValueOf("Status"));
            objsbm.setSessionid(xmlParser.getValueOf("Sessionid"));
            objsbm.setPartnerReqID(xmlParser.getValueOf("PartnerReqID"));
            objsbm.setUsername(xmlParser.getValueOf("username"));
            objsbm.setTimestamp(xmlParser.getValueOf("timestamp"));
        } else {
            objsbm.setStatus(xmlParser.getValueOf("Status"));
            objsbm.setPartnerReqID(xmlParser.getValueOf("PartnerReqID"));
            objsbm.setUsername(xmlParser.getValueOf("username"));
            objsbm.setTimestamp(xmlParser.getValueOf("timestamp"));
            objsbm.setStatusCode(xmlParser.getValueOf("StatusCode"));
            objsbm.setErrorDescription(xmlParser.getValueOf("errorDescription"));
        }
        return objsbm;
    }

    public String createSesssionJSON(SBMSessionIDBean sbmsession) {
        JSONObject o1 = new JSONObject();
        if ("Success".equalsIgnoreCase(sbmsession.getStatus())) {
            o1.put("PartnerReqID", sbmsession.getPartnerReqID());
            o1.put("username", sbmsession.getUsername());
            o1.put("Status", sbmsession.getStatus());
            o1.put("Sessionid", sbmsession.getSessionid());
            o1.put("timestamp", sbmsession.getTimestamp());
        } else {
            o1.put("PartnerReqID", sbmsession.getPartnerReqID());
            o1.put("username", sbmsession.getUsername());
            o1.put("Status", sbmsession.getStatus());
            o1.put("StatusCode", sbmsession.getStatusCode());
            o1.put("errorDescription", sbmsession.getErrorDescription());
            o1.put("timestamp", sbmsession.getTimestamp());
        }
        LogProcessing.sess.info("Session Newgen Response ::: " + o1.toString());
        return o1.toString();
    }

}
