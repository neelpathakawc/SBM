/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.awc.methods;

/**
 *
 * @author Saurish
 */
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

public final class LogProcessing {

    public static Logger sess = null, error = null, cifcreation = null, accountAvailability = null,
            cifretailenquiry = null, accountopening = null, corporatecifcreation = null,
            corporatecifenquiry=null;

    public static void settingLogFiles() {
        InputStream is = null;
        try {
            String currentdir = System.getProperty("user.dir");
            String filePath = currentdir + File.separator + "property" + File.separator + "log4j.properties";
            System.out.println(filePath);
            is = new BufferedInputStream(new FileInputStream(filePath));
            Properties ps = new Properties();
            ps.load(is);
            is.close();

            //proper shutdown all nested loggers if already exists
            org.apache.log4j.LogManager.shutdown();

            //configure log property
            PropertyConfigurator.configure(ps);
            sess = Logger.getLogger("SessionLogs");
            cifcreation = Logger.getLogger("CIFCreation");
            error = Logger.getLogger("Error");
            accountAvailability = Logger.getLogger("AccountAvailability");
            cifretailenquiry = Logger.getLogger("CIFRetailEnquiry");
            accountopening = Logger.getLogger("AccountOpening");
            corporatecifcreation = Logger.getLogger("CorporateCifCreation");
             corporatecifenquiry = Logger.getLogger("CorporateCifenquiry");

        } catch (Exception e) {
            try {
                if (is != null) {
                    is.close();
                }
            } catch (IOException te) {
                System.out.println("LogProcessing=>settingLogFiles()===Exception===>" + te);
                error.info("Error in setting Logger===>\n" + te);
            }
        }
    }
}
