/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.awc.methods;

import com.awc.bean.SBMSessionIDBean;
import com.awc.bean.SessionIDBean;
import com.awc.methods.LogProcessing;
import com.awc.methods.SBM_getSession;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.Produces;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.MediaType;

/**
 * REST Web Service
 *
 * @author Saurish
 */
@Path("get-sessionid")
public class SessionResource {

    @Context
    private UriInfo context;

    /**
     * Creates a new instance of CommonMethods
     */
    public SessionResource() {
    }

    /**
     * Retrieves representation of an instance of
     * com.awc.resources.SessionResource
     *
     * @return an instance of java.lang.String
     */
    @GET
    @Produces(MediaType.APPLICATION_XML)
    public String getXml() {
        //TODO return proper representation object
        throw new UnsupportedOperationException();
    }

    /**
     * PUT method for updating or creating an instance of SessionResource
     *
     * @param partname represents PARTNERNAME
     * @param content representation for the resource
     */
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public String putSessionJSON(@HeaderParam("PARTNERNAME") String partname, String content) {
        LogProcessing.settingLogFiles();
        LogProcessing.sess.info("Header Partner Name ::: " + partname);
        SessionIDBean objBean = new SessionIDBean();
        SBMSessionIDBean objsbm = new SBMSessionIDBean();
        SBM_getSession m = new SBM_getSession();

        objBean = m.parseNewgenRequest(content);
        String sbmResponse = m.callSBMsession(objBean, partname);
        objsbm = m.getresponseSBMsession(sbmResponse);

        return new SBM_getSession().createSesssionJSON(objsbm);

    }
}
