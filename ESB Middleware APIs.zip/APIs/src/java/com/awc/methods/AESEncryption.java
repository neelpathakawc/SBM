/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.awc.methods;

import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

/**
 *
 * @author Administrator
 */
public class AESEncryption {
    private static final String key = "FmoxN5rCTfCtF9c5zGCl/Ni/Yq0sIg4K";
    private static final String initVector = "FmoxN5rCTfCtF9c5";

    String ENCRYPTION_ALGORITHM = "AES";
    String BLOCK_SIZES = "128";
    String KEY_SIZE = "192";
    String ALGORITHM_MODE = "AES/CBC/PKCS5PADDING";
    String ENCODING = "UTF-8";

    public String encrypt(String original) {
        String encrypt = null;
        try {
            IvParameterSpec iv = new IvParameterSpec(initVector.getBytes(ENCODING));
            SecretKeySpec skeySpec = new SecretKeySpec(key.getBytes(ENCODING), ENCRYPTION_ALGORITHM);
            Cipher cipher = Cipher.getInstance(ALGORITHM_MODE);
            cipher.init(Cipher.ENCRYPT_MODE, skeySpec, iv);
            byte[] encrypted = cipher.doFinal(original.getBytes());
            encrypt = new String(Base64.getEncoder().encode(encrypted));
            return encrypt;
        } catch (Exception ex) {
            encrypt = "" + ex;
        }
        return encrypt;
    }

    public String decrypt(String encrypted) {
        String decrypt = null;
        try {
            IvParameterSpec iv = new IvParameterSpec(initVector.getBytes(ENCODING));
            SecretKeySpec skeySpec = new SecretKeySpec(key.getBytes(ENCODING), ENCRYPTION_ALGORITHM);
            Cipher cipher = Cipher.getInstance(ALGORITHM_MODE);
            cipher.init(Cipher.DECRYPT_MODE, skeySpec, iv);
            byte[] original = cipher.doFinal(Base64.getDecoder().decode(encrypted));
            decrypt = new String(original);
            return decrypt;
        } catch (Exception ex) {
            decrypt = "" + ex;
        }
        return decrypt;
    }
}
