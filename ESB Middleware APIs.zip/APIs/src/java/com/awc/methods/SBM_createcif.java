/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.awc.methods;

import com.awc.bean.SBMCIFCreationBean;
import com.awc.xml.XMLParser;
import org.json.JSONObject;

/**
 *
 * @author Saurish
 */
public class SBM_createcif {
    
    XMLParser xmlParser = null;
    
    public SBMCIFCreationBean cifSBMParse(String xmldata) {
        SBMCIFCreationBean objBean = new SBMCIFCreationBean();
        xmlParser = new XMLParser();
        xmlParser.setInputXML(xmldata);
        
        if (xmlParser.getValueOf("Desc").contains("Retail Customer successfully created")) {
            objBean.setName("cif_nos");
            objBean.setSuccCode("ACCT0000");
            objBean.setSuccLongDesc("Success");
            objBean.setValue(xmlParser.getValueOf("CustId"));
            
        } else {
            objBean.setName("cif_nos");
            objBean.setSuccCode("");
            objBean.setSuccLongDesc("Failed");
            objBean.setValue("");
        }
        
        return objBean;
        
    }
    
    public String cifcreationOutput(SBMCIFCreationBean obj) {
        LogProcessing.settingLogFiles();
        JSONObject o = new JSONObject();
        JSONObject succinfo = new JSONObject();
        JSONObject datainfo = new JSONObject();
        JSONObject item0 = new JSONObject();
        succinfo.put("SuccCode", obj.getSuccCode());
        succinfo.put("SuccLongDesc", obj.getSuccLongDesc());
        item0.put("name", obj.getName());
        item0.put("value", obj.getValue());
        datainfo.put("item0", item0);
        o.put("SuccInfo", succinfo);
        o.put("data", datainfo);
        LogProcessing.cifcreation.info("JSON Response :::: " + o.toString());
        return o.toString();
    }
    
}
