/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.awc.methods;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

/**
 *
 * @author Saurish
 */
public class SBMCalling {

    public String callingSBM(String input, String urllink, String partname) {
        String Output = "";
        try {
            SSLTrustManager ssl = new SSLTrustManager();
            ssl.trustAllCerts();
            URL url = new URL(urllink);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setDoOutput(true);
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/xml");
            conn.setRequestProperty("PARTNERNAME", partname);
            OutputStream os = conn.getOutputStream();
            os.write(input.getBytes());
            os.flush();

            BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));

            System.out.println("Output from Server .... ");
            String output;
            while ((output = br.readLine()) != null) {
                System.out.println(output);
                Output = Output + output;
            }
            conn.disconnect();
        } catch (MalformedURLException e) {
            System.out.println("Exception Occured ::: " + e);
            System.out.println("Exception Occured At :: " + e.getStackTrace());
        } catch (IOException e) {
            System.out.println("Exception Occured ::: " + e);
            System.out.println("Exception Occured At :: " + e.getStackTrace());
        }
        return Output;
    }

    public String callingSBMHeadercif(String input, String urllink, String partname, String sessionid) {
        String Output = "";
        try {
            SSLTrustManager ssl = new SSLTrustManager();
            ssl.trustAllCerts();
            URL url = new URL(urllink);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setDoOutput(true);
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/xml");
            conn.setRequestProperty("PARTNERNAME", partname);
            conn.setRequestProperty("SESSIONID", sessionid);
            OutputStream os = conn.getOutputStream();
            os.write(input.getBytes());
            os.flush();

            BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));

            System.out.println("Output from Server .... ");
            String output;
            while ((output = br.readLine()) != null) {
                System.out.println(output);
                Output = Output + output;
            }
            conn.disconnect();
        } catch (MalformedURLException e) {
            System.out.println("Exception Occured ::: " + e);
            System.out.println("Exception Occured At :: " + e.getStackTrace());
        } catch (IOException e) {
            System.out.println("Exception Occured ::: " + e);
            System.out.println("Exception Occured At :: " + e.getStackTrace());
        }
        return Output;
    }
    
    public String callingSBMCifRetailEnquiry(String input,String urllink){
         String Output = "";
        try {
            SSLTrustManager ssl = new SSLTrustManager();
            ssl.trustAllCerts();
            URL url = new URL(urllink);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setDoOutput(true);
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/xml");
            OutputStream os = conn.getOutputStream();
            os.write(input.getBytes());
            os.flush();

            BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));

            System.out.println("Output from Server .... ");
            String output;
            while ((output = br.readLine()) != null) {
                System.out.println(output);
                Output = Output + output;
            }
            conn.disconnect();
        } catch (MalformedURLException e) {
            System.out.println("Exception Occured ::: " + e);
            System.out.println("Exception Occured At :: " + e.getStackTrace());
        } catch (IOException e) {
            System.out.println("Exception Occured ::: " + e);
            System.out.println("Exception Occured At :: " + e.getStackTrace());
        }
        return Output;
    }
    
}
