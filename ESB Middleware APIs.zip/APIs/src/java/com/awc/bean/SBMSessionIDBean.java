/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.awc.bean;

/**
 *
 * @author Saurish
 */
public class SBMSessionIDBean {

    private String PartnerReqID;
    private String username;
    private String Status;
    private String StatusCode;
    private String errorDescription;
    private String timestamp;
    private String Sessionid;

    public String getPartnerReqID() {
        return PartnerReqID;
    }

    public void setPartnerReqID(String PartnerReqID) {
        this.PartnerReqID = PartnerReqID;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getStatus() {
        return Status;
    }

    public void setStatus(String Status) {
        this.Status = Status;
    }

    public String getStatusCode() {
        return StatusCode;
    }

    public void setStatusCode(String StatusCode) {
        this.StatusCode = StatusCode;
    }

    public String getErrorDescription() {
        return errorDescription;
    }

    public void setErrorDescription(String errorDescription) {
        this.errorDescription = errorDescription;
    }

    public String getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }

    public String getSessionid() {
        return Sessionid;
    }

    public void setSessionid(String Sessionid) {
        this.Sessionid = Sessionid;
    }

}
