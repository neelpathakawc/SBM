/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.awc.bean;

/**
 *
 * @author Administrator
 */
public class AESModel {

    String secretKey;
    String iv;
    byte[] data;

    public AESModel() {
    }

    public AESModel(byte[] data, String secretKey) {
        super();
        this.secretKey = secretKey;
        this.iv = secretKey.substring(0, 16);
        this.data = data;
    }

    public String getSecretKey() {
        return secretKey;
    }

    public void setSecretKey(String secretKey) {
        this.secretKey = secretKey;
    }

    public String getIv() {
        return iv;
    }

    public void setIv(String iv) {
        this.iv = iv;
    }

    public byte[] getData() {
        return data;
    }

    public void setData(byte[] data) {
        this.data = data;
    }

}
