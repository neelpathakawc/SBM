/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.awc.bean;

/**
 *
 * @author Saurish
 */
public class SessionIDBean {

    private String channelId;
    private String PartnerReqID;
    private String request;
    private String timeStamp;

    public String getChannelId() {
        return channelId;
    }

    public void setChannelId(String channelId) {
        this.channelId = channelId;
    }

    public String getPartnerReqID() {
        return PartnerReqID;
    }

    public void setPartnerReqID(String PartnerReqID) {
        this.PartnerReqID = PartnerReqID;
    }

    public String getRequest() {
        return request;
    }

    public void setRequest(String request) {
        this.request = request;
    }

    public String getTimeStamp() {
        return timeStamp;
    }

    public void setTimeStamp(String timeStamp) {
        this.timeStamp = timeStamp;
    }

}
