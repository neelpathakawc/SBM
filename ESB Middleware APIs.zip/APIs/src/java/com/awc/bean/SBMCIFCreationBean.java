package com.awc.bean;

/**
 *
 * @author Saurish
 */
public class SBMCIFCreationBean {

    private String SuccCode;
    private String SuccLongDesc;
    private String name;
    private String value;

    public String getSuccCode() {
        return SuccCode;
    }

    public void setSuccCode(String SuccCode) {
        this.SuccCode = SuccCode;
    }

    public String getSuccLongDesc() {
        return SuccLongDesc;
    }

    public void setSuccLongDesc(String SuccLongDesc) {
        this.SuccLongDesc = SuccLongDesc;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

}
